# UniAgent 代码索引（Product T1 · 系统的大脑）

UniAgent 是**整个系统的大脑**（cognition core）——所有者裁决 2026-10-07，
并已在基线 §3.1 收口。本 README 以 Product T0–T3 基线和所有者裁决为准。
旧 Product L0–L3 只保留为历史引用，不再作为当前架构名称。

## Sole Owner（基线 §3.1/§6，权威不改述）

Primary Goal · Goal interpretation · global strategy · Execution Contract
authoring · Goal Evaluation。

四不（§3.1 Boundary）：不拥有 Current WorldBelief；不产生现实动作授权；
不写 Run State / Effect judgment / Outcome Proof；不以模型输出或执行回执
代替 goal satisfaction。

## 大脑的工作方式

- **主循环**：理解 Primary Goal → 形成全局策略 → 创建 Execution
  Contract → 消费 Runtime Outcome envelope → 评价 Goal Satisfaction；
- **自己定义的 tools**：tool 词汇归 UniAgent 所有，可调用；执行经
  realization（Host adapter）投影——DSH Tool 是 Binding/Exposure，不是
  能力类型（ADR-0038）；
  - 两层概念勿混（ADR-0039）：这里的 tools 是**产品层调用词汇**；
    Harness 层的 Tool 是 `tool-registry.yaml` 暴露清单（面向 AI Coder /
    Workbench 等 harness 消费者）。两层经 `backing: capability` +
    `capabilityRef` 单向映射（语义真相在 CapabilityHub），产品代码不
    硬编码 harness skill 路径；
- **realization 可替换**：当前用 DSH 实现（`../UniClaw.Agent.Dsh/`），
  可以在其他宿主用其他方式实现。宿主既有能力（模型、工具、记忆等）
  经 adapter **复用**映射进系统，而不必自研（ADR-0022：codex 与 DSH
  是 dual full UniAgent realizations 的先例）。替换 realization 只动
  adapter，不动本目录。

## 与 Kernel 的缝（单向 typed）

决策缝进（Kernel `Runtime/` 的 AgentDecision / ConsultationTypes）；
RuntimeOutcome envelope 出（Kernel `Outcome/`）。除此之外零依赖。

## 代码归属

| 文件 | 职责 |
|---|---|
| `UniAgent.cs` | Product T1 peer 本体（§3.1/§3.9；ADR-0008 独立程序集） |
| `Goal/PrimaryGoal.cs` | 用户希望现实世界达到的结果（§3.2；GEV-004 最小落地） |
| `Goal/GoalCriterion.cs` | 结构性 satisfaction 判据（GEV-004） |
| `Goal/GoalEvaluationContext.cs` | §3.9 第三输入（user supervisory input） |
| `Evaluation/GoalEvaluation.cs` | 消费 Runtime Outcome envelope 后的评估 |
| `Evaluation/GoalSatisfaction.cs` | satisfaction 维度（GEV-004 D2） |
| `Evaluation/CriterionResult.cs` | criterion 级三值判定 Met/Unmet/Indeterminate（D5） |
| `Evaluation/EvaluationDisposition.cs` | 处置维度（D2/D6） |
| `Profile/UniagentProdProfile.cs` | uniagent-prod 编译身份（loader 交叉核对基准） |
| `Profile/ProductProtocolVersions.cs` | 产品协议常量（PRF-001/ADR-0041 自 adapter 上移） |
| `Profile/CapabilityManifest.cs` | 冻结能力清单与 manifest hash（handshake 权威） |
| `Profile/ProductCapabilities.cs` | 命名能力词汇与禁用名单 |
| `Profile/ProductProfile.cs` | 产品 realization profile 身份（不含 provider/model） |
| `Profile/UniAgentProfile.cs` | host-neutral profile 加载结果（身份+模型角色声明，PRF-002） |
| `Profile/UniAgentProfileYaml.cs` | 产品 profile loader（身份漂移/角色值域 fail-closed，PRF-002） |
| `Profile/ProfileIdentityRenderer.cs` | 从产品 Profile 只读生成身份与职责表达；不引入宿主绑定 |
| `Profile/ProfileYamlDocument.cs` | 产品侧共享 YAML 子集解析器（双 loader 共用，PRF-002） |

`../UniClaw.Agent.Dsh/` 是 DSH realization/adapter（绑定 loader/模型
解析/transport），**不进本维度归属表**（Product T3 不混入 Product T2 索引，同
Capability↔Perception 模式）。PRF-001（ADR-0041）后 adapter 引用本
程序集消费产品身份（Agent.Dsh → Agent 单向）；产品身份类型归本维度，
transport/绑定类型仍归 adapter。

## 记忆

UniAgent 的记忆由 Memory System 组件提供（Product T1 · §9）：管理常用规则与
常用知识。当前为声明占位（零落地），见
`docs/design/memory-system-component-declaration-v0.1.md`。

## 变更规则

goal/策略/contract/evaluation 语义与 tool 词汇进本目录；宿主特有实现
进对应 realization 目录；新增与 Kernel 的缝 = 架构级变更，先走 ADR。

## 已知偏差

- ~~基线 §3.1 定位措辞与所有者裁决不一致~~ → 已由 ARCH-DOC-021
  Narrow Amendment v0.1.2（基线 §25）收口：定位句改为「整个系统的
  大脑（cognition core）」，Owner/Authority/Boundary 零变化。

## 指向

- 基线 §3.1/§3.2/§3.9/§6/§9；Product T1 是当前组件拓扑位置，ADR-0008（独立程序集）、ADR-0022（dual
  realizations）、ADR-0038（tool=exposure）；GEV-004 谱系。
