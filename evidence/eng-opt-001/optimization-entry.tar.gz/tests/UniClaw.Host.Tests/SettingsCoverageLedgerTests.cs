using UniClaw.Host.SettingsCoverage;
using Xunit;

namespace UniClaw.Host.Tests;

[Collection("SettingsCoverageConfigSerial")]
public sealed class SettingsCoverageLedgerTests
{
    private const string RootRoute = "android.settings|rk1:Settings|src=homepage_title|up=0";
    private const string ScrollDescriptor = "com.android.settings:id/main_content_scrollable_container";
    private const string BackDescriptor = "Navigate up";

    private static readonly string[] TargetPages =
    [
        "Network & internet",
        "Connected devices",
        "Apps",
        "Notifications",
        "Battery",
        "Storage",
        "Sound & vibration",
    ];

    private static SettingsCoverageConfig Config() => SettingsCoverageConfig.LoadDefault();

    /// <summary>AGT-017：语义测试不绑默认 profile 值（默认已按所有者指令加深到
    /// 48/8）。本测试类中依赖具体预算数字的用例改用此固定配置。</summary>
    private static SettingsCoverageConfig BoundedConfig()
    {
        var prior = Environment.GetEnvironmentVariable(SettingsCoverageConfig.ConfigPathEnvironmentVariable);
        var path = Path.Combine(Path.GetTempPath(), "uniclaw-ledger-bounded-" + Guid.NewGuid().ToString("N") + ".yaml");
        try
        {
            File.WriteAllText(path, """
                configVersion: "1"
                session:
                  taskTitle: 遍历设置菜单覆盖测试
                  workspace: UniClaw_Product_Tasks
                  workspaceReuse: true
                  autoCloseTurn: false
                bounds:
                  maxSteps: 24
                  maxConsultRounds: 24
                  maxScrolls: 4
                  maxConsecutiveFailures: 3
                  maxDirectiveRetries: 1
                coverage:
                  rootPage: true
                  firstLevelMode: all-visible
                  scrollDiscoveredEntries: 1
                  secondLevelPages: 2
                  backNavigation: true
                  repeatedEntries: 1
                targetPages:
                  - Network & internet
                  - Connected devices
                  - Apps
                  - Notifications
                  - Battery
                  - Storage
                  - Sound & vibration
                termination:
                  onCoverageComplete: true
                  onMaxSteps: true
                  onMaxScrolls: true
                  onConsecutiveFailures: true
                rootRoute: android.settings|rk1:Settings|src=homepage_title|up=0
                scrollContainerDescriptor: com.android.settings:id/main_content_scrollable_container
                backDescriptor: Navigate up
                """);
            Environment.SetEnvironmentVariable(SettingsCoverageConfig.ConfigPathEnvironmentVariable, path);
            return SettingsCoverageConfig.LoadDefault();
        }
        finally
        {
            Environment.SetEnvironmentVariable(SettingsCoverageConfig.ConfigPathEnvironmentVariable, prior);
            try { File.Delete(path); } catch { /* temp cleanup best effort */ }
        }
    }

    private static SettingsCoverageConfig ConfigWith(string yaml)
    {
        var path = Path.Combine(Path.GetTempPath(), $"settings-coverage-ledger-{Guid.NewGuid():N}.yaml");
        File.WriteAllText(path, yaml);
        try
        {
            return SettingsCoverageConfig.Load(path);
        }
        finally
        {
            File.Delete(path);
        }
    }

    private static void Observe(SettingsCoverageLedger ledger, string route, params string[] descriptors) =>
        ledger.RecordObservation(route,
            descriptors.Select(descriptor => ("ui.element", (string?)descriptor)).ToList());

    private static void EnterStep(SettingsCoverageLedger ledger, string descriptor, string routeAfter,
        bool verified = true, string? receiptId = null, string? failureReason = null, string? directive = null) =>
        ledger.RecordStep(new CoverageStepRecord(
            Index: 0,
            DecisionId: $"decision-{descriptor}-{routeAfter}-{Guid.NewGuid():N}",
            DshSessionId: "dsh-session-1",
            TargetRole: "ui.element",
            TargetDescriptor: descriptor,
            EffectClass: "tap",
            DesiredState: null,
            PreActionTargetUnique: true,
            ReceiptId: receiptId ?? $"receipt-{Guid.NewGuid():N}",
            ReceiptOutcome: verified ? "ok" : "mismatch",
            ReceiptCommand: "tap",
            RouteBefore: RootRoute,
            RouteAfter: routeAfter,
            PostCaptureId: $"capture-{Guid.NewGuid():N}",
            Verified: verified,
            FailureReason: failureReason,
            Directive: directive));

    private static void BackStep(SettingsCoverageLedger ledger, string routeBefore, bool verified = true) =>
        ledger.RecordStep(new CoverageStepRecord(
            Index: 0,
            DecisionId: $"decision-back-{Guid.NewGuid():N}",
            DshSessionId: "dsh-session-1",
            TargetRole: "ui.element",
            TargetDescriptor: BackDescriptor,
            EffectClass: "tap",
            DesiredState: null,
            PreActionTargetUnique: true,
            ReceiptId: $"receipt-{Guid.NewGuid():N}",
            ReceiptOutcome: verified ? "ok" : "mismatch",
            ReceiptCommand: "tap",
            RouteBefore: routeBefore,
            RouteAfter: verified ? RootRoute : routeBefore,
            PostCaptureId: $"capture-{Guid.NewGuid():N}",
            Verified: verified,
            FailureReason: verified ? null : "back-not-verified",
            Directive: null));

    private static void ScrollStep(SettingsCoverageLedger ledger, bool verified) =>
        ledger.RecordStep(new CoverageStepRecord(
            Index: 0,
            DecisionId: $"decision-scroll-{Guid.NewGuid():N}",
            DshSessionId: "dsh-session-1",
            TargetRole: "ui.element",
            TargetDescriptor: ScrollDescriptor,
            EffectClass: "swipe-up",
            DesiredState: "scroll-down",
            PreActionTargetUnique: true,
            ReceiptId: $"receipt-{Guid.NewGuid():N}",
            ReceiptOutcome: verified ? "ok" : "mismatch",
            ReceiptCommand: "swipe-up",
            RouteBefore: RootRoute,
            RouteAfter: RootRoute,
            PostCaptureId: $"capture-{Guid.NewGuid():N}",
            Verified: verified,
            FailureReason: verified ? null : "post-action-target-unique",
            Directive: null));

    private static void EnterAllTargetPages(SettingsCoverageLedger ledger)
    {
        foreach (var page in TargetPages)
            EnterStep(ledger, page, $"android.settings|route:{page}");
    }

    private static CoverageItem Item(SettingsCoverageLedger ledger, string requirement)
    {
        var report = ledger.Report(Config());
        return report.Items.Single(item => item.Requirement == requirement);
    }

    private static CoverageItem Item(SettingsCoverageLedger ledger, SettingsCoverageConfig config, string requirement)
    {
        var report = ledger.Report(config);
        return report.Items.Single(item => item.Requirement == requirement);
    }

    [Fact]
    public void RootObservation_CoversRootPage()
    {
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages[0], TargetPages[1]);

        var item = Item(ledger, "root-page");
        Assert.True(item.Covered);

        var snapshot = ledger.Snapshot(Config());
        Assert.Equal(RootRoute, snapshot.CurrentRoute);
        Assert.False(snapshot.CoverageComplete);
    }

    [Fact]
    public void DynamicRootEntries_ExposeFrontierVisitedAndStructuralSkipReasons()
    {
        var config = ConfigWith("""
            configVersion: "1"
            session:
              taskTitle: dynamic-root
              workspace: UniClaw_Product_Tasks
              workspaceReuse: true
              autoCloseTurn: false
            bounds:
              maxSteps: 24
              maxConsultRounds: 24
              maxScrolls: 4
              maxConsecutiveFailures: 3
              maxDirectiveRetries: 1
            coverage:
              rootPage: true
              firstLevelMode: all-visible
              scrollDiscoveredEntries: 1
              secondLevelPages: 1
              backNavigation: false
              repeatedEntries: 0
            targetPages:
              - Network & internet
            dynamicRootEntries:
              enabled: true
              mode: all-visible
              excludedDescriptors:
                - Search settings
            termination:
              onCoverageComplete: true
              onMaxSteps: true
              onMaxScrolls: true
              onConsecutiveFailures: true
            rootRoute: android.settings|rk1:Settings|src=homepage_title|up=0
            scrollContainerDescriptor: com.android.settings:id/main_content_scrollable_container
            backDescriptor: Navigate up
            """);
        var ledger = new SettingsCoverageLedger();
        ledger.RecordObservation(RootRoute, new[]
        {
            ("ui.element", (string?)"Network & internet", (string?)null),
            ("ui.element", (string?)"Search settings", (string?)null),
            ("ui.element", (string?)"Accessibility", (string?)null),
            ("ui.element", (string?)"Navigate up", (string?)null),
            ("ui.element", (string?)ScrollDescriptor, (string?)null),
            ("ui.element", (string?)"Dismiss", (string?)"android:id/button1"),
            ("ui.container", (string?)"Container", (string?)null),
        });

        Assert.Equal("enter", ledger.Snapshot(config).NextDirectiveKind);
        EnterStep(ledger, "Network & internet", "android.settings|route:Network");
        BackStep(ledger, "android.settings|route:Network");

        var report = ledger.Report(config);
        Assert.Equal(["Accessibility"], report.DynamicRootFrontier);
        Assert.Empty(report.DynamicRootVisited);
        Assert.Equal("configured-target", report.DynamicRootSkipReasons!["Network & internet"]);
        Assert.Equal("explicit-exclusion", report.DynamicRootSkipReasons["Search settings"]);
        Assert.Equal("back-descriptor", report.DynamicRootSkipReasons["Navigate up"]);
        Assert.Equal("scroll-container", report.DynamicRootSkipReasons[ScrollDescriptor]);
        Assert.Equal("framework-control", report.DynamicRootSkipReasons["Dismiss"]);
        Assert.Equal("non-ui-element-role", report.DynamicRootSkipReasons["Container"]);
        Assert.Equal("enter", ledger.Snapshot(config).NextDirectiveKind);
        Assert.Contains("Accessibility", ledger.Snapshot(config).NextDirective);

        EnterStep(ledger, "Accessibility", "android.settings|route:Accessibility");
        var visited = ledger.Report(config).DynamicRootVisited;
        Assert.Equal(["Accessibility"], visited);
        Assert.Empty(ledger.Report(config).DynamicRootFrontier);
    }

    [Fact]
    public void DynamicNestedEntries_PerPageLimitDoesNotResetOnEveryObservation()
    {
        var config = Config() with { DynamicNestedEntries = new DynamicNestedEntriesConfig(true, 1, 1) };
        const string page = "android.settings|route:Network";
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, "Network & internet");
        EnterStep(ledger, "Network & internet", page);
        Observe(ledger, page, "Internet", "SIMs");
        Observe(ledger, page, "Internet", "SIMs");
        Assert.Equal(new[] { $"{page}>Internet" }, ledger.DynamicNestedFrontier(config));
    }

    [Fact]
    public void DynamicNestedEntries_DriveCurrentPageAndTrackVisited()
    {
        var config = ConfigWith("""
            configVersion: "1"
            session:
              taskTitle: dynamic-nested
              workspace: w
              workspaceReuse: true
              autoCloseTurn: false
            bounds:
              maxSteps: 12
              maxConsultRounds: 12
              maxScrolls: 1
              maxConsecutiveFailures: 2
              maxDirectiveRetries: 1
            coverage:
              rootPage: true
              firstLevelMode: all-visible
              scrollDiscoveredEntries: 1
              secondLevelPages: 1
              backNavigation: false
              repeatedEntries: 0
            targetPages:
              - Network & internet
            dynamicNestedEntries:
              enabled: true
              maxDepth: 1
              maxEntriesPerPage: 2
            termination:
              onCoverageComplete: true
              onMaxSteps: true
              onMaxScrolls: true
              onConsecutiveFailures: true
            rootRoute: android.settings|rk1:Settings|src=homepage_title|up=0
            scrollContainerDescriptor: com.android.settings:id/main_content_scrollable_container
            backDescriptor: Navigate up
            """);
        const string page = "android.settings|route:Network";
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, "Network & internet");
        EnterStep(ledger, "Network & internet", page);
        ledger.RecordObservation(page, new[]
        {
            ("ui.element", (string?)"Private DNS"),
            ("switch", (string?)"Use Wi-Fi"),
            ("ui.element", (string?)"Navigate up"),
        });

        var snapshot = ledger.Snapshot(config);
        Assert.Equal("nested-enter", snapshot.NextDirectiveKind);
        Assert.Contains("Private DNS", snapshot.NextDirective);
        Assert.Contains($"{page}>Private DNS", ledger.Report(config).DynamicNestedFrontier!);
        Assert.Contains($"{page}>Use Wi-Fi", ledger.Report(config).DynamicNestedSkipReasons!.Keys);

        ledger.RecordStep(new CoverageStepRecord(
            0, "decision-private-dns", "dsh-session-1", "ui.element", "Private DNS", "tap", null,
            true, "receipt-private-dns", "ok", "tap", page, "android.settings|route:Private DNS",
            "capture-private-dns", true, null, null));
        Assert.Contains($"{page}>Private DNS", ledger.Report(config).DynamicNestedVisited!);
    }

    [Fact]
    public void IdentityOnlySettingsRoute_IsRootFallback()
    {
        var config = Config();
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, "android.settings");
        Assert.True(ledger.Report(config).Items[0].Covered);

        var dynamic = ConfigWith("""
            configVersion: "1"
            session:
              taskTitle: identity-only
              workspace: w
              workspaceReuse: true
              autoCloseTurn: false
            bounds:
              maxSteps: 4
              maxConsultRounds: 4
              maxScrolls: 1
              maxConsecutiveFailures: 2
              maxDirectiveRetries: 1
            coverage:
              rootPage: true
              firstLevelMode: all-visible
              scrollDiscoveredEntries: 1
              secondLevelPages: 1
              backNavigation: false
              repeatedEntries: 0
            targetPages:
              - Network & internet
            dynamicRootEntries:
              enabled: true
              mode: all-visible
            termination:
              onCoverageComplete: true
              onMaxSteps: true
              onMaxScrolls: true
              onConsecutiveFailures: true
            rootRoute: android.settings|rk1:Settings|src=homepage_title|up=0
            scrollContainerDescriptor: com.android.settings:id/main_content_scrollable_container
            backDescriptor: Navigate up
            """);
        ledger.RecordObservation("android.settings", new[]
        {
            ("ui.element", (string?)"Child leaked from identity-only route", (string?)null)
        });
        Assert.Empty(ledger.Report(dynamic).DynamicRootFrontier!);
    }

    [Fact]
    public void EnterAllTargetsAndBack_CoversFirstLevelSecondLevelAndBack()
    {
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);
        EnterAllTargetPages(ledger);
        BackStep(ledger, $"android.settings|route:{TargetPages[^1]}");

        var config = BoundedConfig();
        Assert.True(Item(ledger, config, "first-level-all-visible").Covered);
        Assert.True(Item(ledger, config, "second-level-pages").Covered);
        Assert.True(Item(ledger, config, "back-navigation").Covered);
    }

    [Fact]
    public void ExplicitNestedEntry_IsDrivenAndUnknownEntryIsIgnored()
    {
        var config = ConfigWith("""
            configVersion: "1"
            session:
              taskTitle: nested
              workspace: UniClaw_Product_Tasks
              workspaceReuse: true
              autoCloseTurn: false
            bounds:
              maxSteps: 24
              maxConsultRounds: 24
              maxScrolls: 2
              maxConsecutiveFailures: 3
              maxDirectiveRetries: 1
            coverage:
              rootPage: true
              firstLevelMode: all-visible
              scrollDiscoveredEntries: 1
              secondLevelPages: 1
              backNavigation: true
              repeatedEntries: 0
            targetPages:
              - Network & internet
            deepTraversal:
              enabled: true
              maxDepth: 1
              maxEntriesPerPage: 1
              nestedEntries:
                - Network & internet > Wi-Fi
            termination:
              onCoverageComplete: true
              onMaxSteps: true
              onMaxScrolls: true
              onConsecutiveFailures: true
            rootRoute: android.settings|rk1:Settings|src=homepage_title|up=0
            scrollContainerDescriptor: com.android.settings:id/main_content_scrollable_container
            backDescriptor: Navigate up
            """);
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages[0]);
        EnterStep(ledger, TargetPages[0], "android.settings|rk1:Network & internet|src=title|up=1");
        Observe(ledger, "android.settings|rk1:Network & internet|src=title|up=1", "Wi-Fi", "Unknown control");

        var pending = ledger.Snapshot(config);
        Assert.Equal("nested-enter", pending.NextDirectiveKind);
        Assert.Contains("<Wi-Fi>", pending.NextDirective);
        Assert.DoesNotContain("Unknown control", pending.NextDirective);

        ledger.RecordStep(new CoverageStepRecord(
            Index: 2,
            DecisionId: "nested-entry",
            DshSessionId: "dsh",
            TargetRole: "ui.element",
            TargetDescriptor: "Wi-Fi",
            EffectClass: "tap",
            DesiredState: null,
            PreActionTargetUnique: true,
            ReceiptId: "nested-receipt",
            ReceiptOutcome: "ok",
            ReceiptCommand: "tap",
            RouteBefore: "android.settings|rk1:Network & internet|src=title|up=1",
            RouteAfter: "android.settings|rk1:Wi-Fi|src=title|up=1",
            PostCaptureId: "nested-capture",
            Verified: true,
            FailureReason: null,
            Directive: pending.NextDirective));
        Assert.True(Item(ledger, config, "nested-pages").Covered);
    }

    [Fact]
    public void ScrollDiscoveredEntry_RequiresVerifiedScrollBeforeObservation()
    {
        var ledger = new SettingsCoverageLedger();
        // Root observation before any scroll: "Accessibility" must NOT become a candidate.
        Observe(ledger, RootRoute, TargetPages);
        ScrollStep(ledger, verified: true);
        // Root observation after the verified scroll: "Accessibility" is discovered.
        Observe(ledger, RootRoute, "Accessibility");
        EnterStep(ledger, "Accessibility", "android.settings|route:Accessibility");

        var item = Item(ledger, "scroll-discovered-entry");
        Assert.True(item.Covered);
        Assert.NotNull(item.Evidence);
        Assert.Contains("Accessibility", item.Evidence);
    }

    [Fact]
    public void UnverifiedScroll_DoesNotCountScrollsOrProduceCandidates()
    {
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);
        ScrollStep(ledger, verified: false);
        Observe(ledger, RootRoute, "Accessibility");
        EnterStep(ledger, "Accessibility", "android.settings|route:Accessibility");

        var report = ledger.Report(Config());
        Assert.Equal(1, report.ScrollAttempts);
        Assert.Equal(0, report.ScrollsUsed);
        Assert.False(report.Items.Single(item => item.Requirement == "scroll-discovered-entry").Covered);
    }

    [Fact]
    public void RepeatedEntry_DifferentReceipts_SatisfiesRepeatedEntry()
    {
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);
        EnterStep(ledger, "Battery", "android.settings|route:Battery", receiptId: "receipt-1");
        EnterStep(ledger, "Battery", "android.settings|route:Battery-again", receiptId: "receipt-2");

        Assert.True(Item(ledger, "repeated-entry").Covered);

        var report = ledger.Report(Config());
        Assert.Equal(report.StepsExecuted, report.StepsVerified);
        Assert.Null(report.FirstDivergence);
    }

    [Fact]
    public void DuplicateDispatchedStepsWithoutVerifiedBetween_FlagsFirstDivergence()
    {
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);
        EnterStep(ledger, "Apps", "android.settings|route:Apps", verified: false,
            failureReason: "receipt-no-route-change", receiptId: "receipt-1");
        EnterStep(ledger, "Apps", "android.settings|route:Apps", verified: false,
            failureReason: "receipt-no-route-change", receiptId: "receipt-2");

        var divergence = ledger.Report(Config()).FirstDivergence;
        Assert.NotNull(divergence);
        Assert.Contains("duplicate-effect-no-interleaving-verified-step", divergence);
    }

    [Fact]
    public void DuplicateDispatchedStepsWithVerifiedBetween_NotFlagged()
    {
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);
        EnterStep(ledger, "Apps", "android.settings|route:Apps", verified: false,
            failureReason: "receipt-no-route-change", receiptId: "receipt-1");
        EnterStep(ledger, "Notifications", "android.settings|route:Notifications", verified: true,
            receiptId: "receipt-2");
        EnterStep(ledger, "Apps", "android.settings|route:Apps", verified: false,
            failureReason: "receipt-no-route-change", receiptId: "receipt-3");

        var divergence = ledger.Report(Config()).FirstDivergence;
        Assert.NotNull(divergence);
        Assert.DoesNotContain("duplicate-effect", divergence);
    }

    [Fact]
    public void ConsecutiveFailures_TriggerMaxConsecutiveFailuresReached()
    {
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);
        for (var attempt = 0; attempt < Config().Bounds.MaxConsecutiveFailures; attempt++)
        {
            EnterStep(ledger, "Apps", RootRoute, verified: false,
                failureReason: "post-action-target-unique");
        }

        var snapshot = ledger.Snapshot(Config());
        Assert.True(snapshot.MaxConsecutiveFailuresReached);
        Assert.Equal(Config().Bounds.MaxConsecutiveFailures, ledger.Report(Config()).StepsExecuted);
        Assert.Equal(0, ledger.Report(Config()).StepsVerified);
    }

    [Fact]
    public void ConsultCeiling_UsesFinalTotal_LeavingCurrentGrantsToKernel()
    {
        var ledger = new SettingsCoverageLedger();
        var config = BoundedConfig();
        config = config with { Bounds = config.Bounds with { MaxConsultRounds = 3, MaxTotalConsultRounds = 6 } };
        for (var i = 0; i < 3; i++)
            ledger.RecordConsultRound($"decision-{i}");
        Assert.False(ledger.Snapshot(config).MaxConsultRoundsReached);
        for (var i = 3; i < 6; i++)
            ledger.RecordConsultRound($"decision-{i}");
        Assert.True(ledger.Snapshot(config).MaxConsultRoundsReached);
    }

    [Fact]
    public void GoalDirectedMode_IgnoresLegacyTotalsAndSingleGrantCeilingsWithoutAuthorizedTotal()
    {
        var ledger = new SettingsCoverageLedger();
        var config = BoundedConfig() with
        {
            Bounds = BoundedConfig().Bounds with
            {
                MaxSteps = 3,
                MaxConsultRounds = 3,
                MaxTotalSteps = 6,
                MaxTotalConsultRounds = 6,
                GoalDirectedContinuationEnabled = true,
            },
        };
        for (var i = 0; i < 7; i++)
        {
            EnterStep(ledger, $"target-{i}", $"route-{i}", verified: false);
            ledger.RecordConsultRound($"decision-{i}");
        }

        var snapshot = ledger.Snapshot(config);

        Assert.False(snapshot.MaxStepsReached);
        Assert.False(snapshot.MaxConsultRoundsReached);
        Assert.True(snapshot.MaxConsecutiveFailuresReached);
        Assert.False(snapshot.CoverageComplete);
    }

    [Fact]
    public void GoalDirectedMode_StopsAtExplicitAuthorizedTotalCeilings()
    {
        var ledger = new SettingsCoverageLedger();
        var config = BoundedConfig() with
        {
            Bounds = BoundedConfig().Bounds with
            {
                MaxSteps = 3,
                MaxConsultRounds = 3,
                GoalDirectedContinuationEnabled = true,
                AuthorizedTotalSteps = 4,
                AuthorizedTotalConsultRounds = 4,
            },
        };
        for (var i = 0; i < 4; i++)
        {
            EnterStep(ledger, $"target-{i}", $"route-{i}", verified: true);
            ledger.RecordConsultRound($"decision-{i}");
        }

        var snapshot = ledger.Snapshot(config);

        Assert.True(snapshot.MaxStepsReached);
        Assert.True(snapshot.MaxConsultRoundsReached);
    }

    [Fact]
    public void GoalDirectedMode_ScrollLimitBlocksSwipesButKeepsOtherVisibleBranchesActionable()
    {
        var ledger = new SettingsCoverageLedger();
        var config = BoundedConfig() with
        {
            Bounds = BoundedConfig().Bounds with
            {
                MaxScrolls = 0,
                GoalDirectedContinuationEnabled = true,
            },
        };
        Observe(ledger, config.RootRoute, TargetPages[0]);

        var snapshot = ledger.Snapshot(config);

        Assert.True(snapshot.MaxScrollsReached);
        Assert.False(snapshot.CoverageComplete);
        Assert.Equal("enter", snapshot.NextDirectiveKind);
        Assert.Contains(TargetPages[0], snapshot.NextDirective);
    }

    [Fact]
    public void MaxStepsReached_AfterExecutingBoundSteps()
    {
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);
        for (var attempt = 0; attempt < 24; attempt++)
        {
            EnterStep(ledger, "Apps", RootRoute, verified: false,
                failureReason: "post-action-target-unique");
        }

        Assert.True(ledger.Snapshot(BoundedConfig()).MaxStepsReached);
    }

    [Fact]
    public void NextDirective_FollowsPrioritySequence()
    {
        var ledger = new SettingsCoverageLedger();

        // Initial: first not-entered target page.
        Observe(ledger, RootRoute, TargetPages);
        var initial = ledger.Snapshot(Config());
        Assert.Equal("enter", initial.NextDirectiveKind);
        Assert.Contains($"<{TargetPages[0]}>", initial.NextDirective);

        // All targets entered, currently inside a second-level page → back.
        EnterAllTargetPages(ledger);
        Observe(ledger, $"android.settings|route:{TargetPages[^1]}");
        var insideSecondLevel = ledger.Snapshot(Config());
        Assert.Equal("back", insideSecondLevel.NextDirectiveKind);
        Assert.Contains($"<{BackDescriptor}>", insideSecondLevel.NextDirective);

        // Back at the root → scroll.
        Observe(ledger, RootRoute);
        var backAtRoot = ledger.Snapshot(Config());
        Assert.Equal("scroll", backAtRoot.NextDirectiveKind);
        Assert.Contains($"<{ScrollDescriptor}>", backAtRoot.NextDirective);

        // Verified scroll discovers a new entry; enter it → re-enter directive.
        //（滚动后的根页观察同时含既有目标与新条目——可见性约束下
        // re-enter 只指挥当前可见的已进入目标。）
        ScrollStep(ledger, verified: true);
        Observe(ledger, RootRoute, TargetPages.Append("Accessibility").ToArray());
        EnterStep(ledger, "Accessibility", "android.settings|route:Accessibility");
        var afterScrollEntry = ledger.Snapshot(Config());
        Assert.Equal("re-enter", afterScrollEntry.NextDirectiveKind);
        Assert.Contains($"<{TargetPages[0]}>", afterScrollEntry.NextDirective);

        // Complete the coverage (re-enter first target, verify back, stay at root) → null.
        EnterStep(ledger, TargetPages[0], "android.settings|route:Network-Reentry");
        BackStep(ledger, "android.settings|route:Network-Reentry");
        Observe(ledger, RootRoute, TargetPages);
        var complete = ledger.Snapshot(Config());
        Assert.True(complete.CoverageComplete);
        Assert.Null(complete.NextDirective);
        Assert.Null(complete.NextDirectiveKind);
    }

    [Fact]
    public void FrameworkButtonRid_IsNeverAScrollCandidate()
    {
        // AGT-011 §5：对话框按钮（android:id/button1|2 框架 rid）不是遍历
        // 入口；非按钮 rid（如 search_action）仍可成为候选（语料实证）。
        var ledger = new SettingsCoverageLedger();
        EnterAllTargetPages(ledger);
        ScrollStep(ledger, verified: true);
        ledger.RecordObservation(RootRoute, new[]
        {
            ("ui.element", "DISMISS", "android:id/button1"),
            ("ui.element", "CANCEL", "android:id/button2"),
            ("ui.element", "Search settings", "com.android.settings:id/search_action_bar"),
        });
        var snapshot = ledger.Snapshot(Config());
        if (snapshot.NextDirectiveKind == "enter")
        {
            Assert.Contains("<Search settings>", snapshot.NextDirective);
            Assert.DoesNotContain("<DISMISS>", snapshot.NextDirective);
            Assert.DoesNotContain("<CANCEL>", snapshot.NextDirective);
        }
        else
        {
            Assert.Equal("scroll", snapshot.NextDirectiveKind); // 无候选则滚动
        }
    }

    [Fact]
    public void FailedEntryCandidate_IsSkipped_NotRetried()
    {
        // AGT-007：候选进入验证失败（如路由指纹碰撞页）后不得重试。
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);
        EnterAllTargetPages(ledger);
        ScrollStep(ledger, verified: true);
        Observe(ledger, RootRoute, TargetPages.Append("Accessibility").Append("System").ToArray());
        // Accessibility 进入失败（Verified=false，路由未变）。
        ledger.RecordStep(new CoverageStepRecord(
            99, "decision-x", null, "ui.element", "Accessibility", "tap", null,
            true, "receipt-x", "DeliveryCompleted", "tap",
            RootRoute, RootRoute, null, false, "post-action-target-unique", null));

        var snapshot = ledger.Snapshot(ConfigWith("""
            configVersion: "1"
            session:
              taskTitle: fail-skip-test
              workspace: UniClaw_Product_Tasks
              workspaceReuse: true
              autoCloseTurn: false
            bounds:
              maxSteps: 24
              maxConsultRounds: 24
              maxScrolls: 4
              maxConsecutiveFailures: 3
              maxDirectiveRetries: 1
            coverage:
              rootPage: true
              firstLevelMode: all-visible
              scrollDiscoveredEntries: 2
              secondLevelPages: 2
              backNavigation: false
              repeatedEntries: 0
            targetPages:
              - Network & internet
            termination:
              onCoverageComplete: true
              onMaxSteps: true
              onMaxScrolls: true
              onConsecutiveFailures: true
            rootRoute: android.settings|rk1:Settings|src=homepage_title|up=0
            scrollContainerDescriptor: com.android.settings:id/main_content_scrollable_container
            backDescriptor: Navigate up
            """));
        // 失败的 Accessibility 被跳过；下一个候选是 System。
        Assert.Equal("enter", snapshot.NextDirectiveKind);
        Assert.Contains("<System>", snapshot.NextDirective);
        Assert.DoesNotContain("<Accessibility>", snapshot.NextDirective);
    }

    [Fact]
    public void BackDescriptor_IsNeverAScrollCandidate()
    {
        // AGT-006 补：标题与根页相同的子页会被误判为根页，其 "Navigate up"
        // 不应成为滚动候选目标（真机 c4 step 21 实证）。
        var ledger = new SettingsCoverageLedger();
        EnterAllTargetPages(ledger);
        ScrollStep(ledger, verified: true);
        Observe(ledger, RootRoute, TargetPages.Append(BackDescriptor).ToArray());

        var snapshot = ledger.Snapshot(Config());
        if (snapshot.NextDirectiveKind == "enter")
            Assert.DoesNotContain($"<{BackDescriptor}>", snapshot.NextDirective);
    }

    [Fact]
    public void EnteredScrollCandidate_IsNotReEntered_NextDirectiveAdvances()
    {
        // AGT-006 回归：候选不在 TargetPages 内，曾因 entered 跟踪只算
        // TargetPages 而被反复重进（30 enters/1 swipe 的真机循环）。
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);
        EnterAllTargetPages(ledger);
        ScrollStep(ledger, verified: true);
        Observe(ledger, RootRoute, TargetPages.Append("Accessibility").Append("System").ToArray());
        EnterStep(ledger, "Accessibility", "android.settings|route:Accessibility");
        BackStep(ledger, "android.settings|route:Accessibility");
        Observe(ledger, RootRoute, TargetPages.Append("Accessibility").Append("System").ToArray());

        var snapshot = ledger.Snapshot(ConfigWith("""
            configVersion: "1"
            session:
              taskTitle: candidate-test
              workspace: UniClaw_Product_Tasks
              workspaceReuse: true
              autoCloseTurn: false
            bounds:
              maxSteps: 24
              maxConsultRounds: 24
              maxScrolls: 4
              maxConsecutiveFailures: 3
              maxDirectiveRetries: 1
            coverage:
              rootPage: true
              firstLevelMode: all-visible
              scrollDiscoveredEntries: 2
              secondLevelPages: 2
              backNavigation: false
              repeatedEntries: 0
            targetPages:
              - Network & internet
            termination:
              onCoverageComplete: true
              onMaxSteps: true
              onMaxScrolls: true
              onConsecutiveFailures: true
            rootRoute: android.settings|rk1:Settings|src=homepage_title|up=0
            scrollContainerDescriptor: com.android.settings:id/main_content_scrollable_container
            backDescriptor: Navigate up
            """));
        // 已进入的 Accessibility 不再被指挥；下一个候选是 System。
        Assert.Equal("enter", snapshot.NextDirectiveKind);
        Assert.Contains("<System>", snapshot.NextDirective);
        Assert.DoesNotContain("<Accessibility>", snapshot.NextDirective);
    }

    [Fact]
    public void Report_ComputesCoverageAndStepSuccessRates()
    {
        var ledger = new SettingsCoverageLedger();
        var config = ConfigWith("""
            configVersion: "1"
            session:
              taskTitle: rate-test
              workspace: UniClaw_Product_Tasks
              workspaceReuse: true
              autoCloseTurn: false
            bounds:
              maxSteps: 24
              maxConsultRounds: 24
              maxScrolls: 4
              maxConsecutiveFailures: 3
              maxDirectiveRetries: 1
            coverage:
              rootPage: true
              firstLevelMode: all-visible
              scrollDiscoveredEntries: 1
              secondLevelPages: 2
              backNavigation: false
              repeatedEntries: 0
            targetPages:
              - Network & internet
            termination:
              onCoverageComplete: true
              onMaxSteps: true
              onMaxScrolls: true
              onConsecutiveFailures: true
            rootRoute: android.settings|rk1:Settings|src=homepage_title|up=0
            scrollContainerDescriptor: com.android.settings:id/main_content_scrollable_container
            backDescriptor: Navigate up
            """);
        Observe(ledger, RootRoute, "Network & internet");
        EnterStep(ledger, "Network & internet", "android.settings|route:Network");
        EnterStep(ledger, "Connected devices", "android.settings|route:Devices");
        EnterStep(ledger, "Apps", "android.settings|route:Apps");
        EnterStep(ledger, "Notifications", "android.settings|route:Notifications",
            verified: false, failureReason: "post-action-target-unique");

        var report = ledger.Report(config);
        Assert.Equal(5.0 / 6.0, report.CoverageRate, precision: 6);   // scroll-discovered-entry uncovered
        Assert.Equal(3.0 / 4.0, report.StepSuccessRate, precision: 6); // 3 verified of 4 executed
    }

    [Fact]
    public void Report_StatusReflectsCoverageCompletionOrBoundedStop()
    {
        var complete = new SettingsCoverageLedger();
        Observe(complete, RootRoute, TargetPages);
        EnterAllTargetPages(complete);
        // scroll-discovered + repeated-entry + back still needed for full coverage.
        ScrollStep(complete, verified: true);
        Observe(complete, RootRoute, "Accessibility");
        EnterStep(complete, "Accessibility", "android.settings|route:Accessibility");
        EnterStep(complete, TargetPages[0], "android.settings|route:Network-Reentry");
        BackStep(complete, "android.settings|route:Network-Reentry");

        var completeReport = complete.Report(Config());
        Assert.Equal("CoverageComplete", completeReport.Status);
        Assert.Empty(completeReport.UncoveredItems);
        Assert.Equal(1.0, completeReport.CoverageRate, precision: 6);

        var truncated = new SettingsCoverageLedger();
        Observe(truncated, RootRoute, TargetPages);
        for (var attempt = 0; attempt < 3; attempt++)
        {
            EnterStep(truncated, "Apps", RootRoute, verified: false,
                failureReason: "post-action-target-unique");
        }

        var truncatedReport = truncated.Report(Config());
        Assert.Equal("BoundedStop", truncatedReport.Status);
        Assert.NotEmpty(truncatedReport.UncoveredItems);
        Assert.Contains("first-level-all-visible", truncatedReport.UncoveredItems);
    }

    // AGT-019 Q4（owner 订正：置信面即 ElementEpistemic 轴，Host 侧载体 =
    // 观测里的 NativeRid——XML 连接 = 双源/Observed，缺失 = 视觉单源/
    // Partial）。skip-first：同轮可见候选双源优先，单源跳过不丢弃。

    [Fact]
    public void NextDirective_PrefersDualSourceEntry_OverEarlierListedSingleSource()
    {
        var ledger = new SettingsCoverageLedger();
        ledger.RecordObservation(RootRoute, new (string, string?, string?)[]
        {
            ("ui.element", "Apps", null),                     // 单源（视觉）
            ("ui.element", "Battery", "android:id/battery"),  // 双源（XML 连接）
        });

        var snapshot = ledger.Snapshot(Config());

        Assert.Equal("enter", snapshot.NextDirectiveKind);
        Assert.Contains("Battery", snapshot.NextDirective);
    }

    [Fact]
    public void NextDirective_SingleSourceEntry_StillSelected_WhenNoDualSourceVisible()
    {
        var ledger = new SettingsCoverageLedger();
        ledger.RecordObservation(RootRoute, new (string, string?, string?)[]
        {
            ("ui.element", "Apps", null),
        });

        var snapshot = ledger.Snapshot(Config());

        Assert.Equal("enter", snapshot.NextDirectiveKind);
        Assert.Contains("Apps", snapshot.NextDirective);
    }

    [Fact]
    public void OwnerEventStream_RecordsTypedFactsWithMonotonicSequence()
    {
        var ledger = new SettingsCoverageLedger();

        ledger.RecordObservation(RootRoute, new[] { ("ui.element", (string?)"Apps") });
        ledger.RecordPopupState("absent");
        EnterStep(ledger, "Apps", "android.settings|route:Apps", receiptId: "receipt-event-1");

        Assert.Equal(
            [
                CoverageEventType.ObservationAccepted,
                CoverageEventType.PopupStateObserved,
                CoverageEventType.EffectReceiptProduced,
                CoverageEventType.PostActionVerified,
            ],
            ledger.Events.Select(item => item.Type));
        Assert.Equal(ledger.Events.Count, ledger.Events.Select(item => item.Sequence).Distinct().Count());
        Assert.True(ledger.Events.Zip(ledger.Events.Skip(1)).All(pair => pair.First.Sequence < pair.Second.Sequence));
        Assert.DoesNotContain(ledger.Events, item => item.Owner == "uniclaw-runtime");
    }

    [Fact]
    public void AgentSkip_IsZeroEffect_Idempotent_AndSeparateFromStructuralSkip()
    {
        var ledger = new SettingsCoverageLedger();

        Assert.True(ledger.TryMarkTargetSkipped(
            "Accessibility", "decision-skip-1", "not-actionable", ["event-12"]));
        Assert.False(ledger.TryMarkTargetSkipped(
            "Accessibility", "decision-skip-1", "duplicate", ["event-13"]));

        var mark = Assert.Single(ledger.TargetMarks).Value;
        Assert.Equal(TargetCoverageMarkKind.Skipped, mark.Kind);
        Assert.Equal(["Accessibility"], ledger.AgentSkippedTargets);
        Assert.Single(ledger.Events, item => item.Type == CoverageEventType.TargetCoverageMarked);
        Assert.Empty(ledger.Events.Where(item => item.Type == CoverageEventType.EffectReceiptProduced));
        Assert.Empty(ledger.Report(Config()).StructuralSkippedTargets!);
    }

    [Fact]
    public void AgentSkip_ExcludesTargetFromNextDirectiveCandidates()
    {
        // TRAJECTORY-001 Skip 回路：Agent skip 落账后，NextDirective 的
        // enter 候选不再包含被跳过目标（与 structural-skip 同一排除面）。
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);

        var before = ledger.Snapshot(Config());
        Assert.Equal("enter", before.NextDirectiveKind);
        Assert.Contains($"<{TargetPages[0]}>", before.NextDirective);

        Assert.True(ledger.TryMarkTargetSkipped(
            TargetPages[0], "decision-skip-rt", "not-actionable", ["event:12"]));

        var after = ledger.Snapshot(Config());
        Assert.Equal("enter", after.NextDirectiveKind);
        Assert.DoesNotContain($"<{TargetPages[0]}>", after.NextDirective);
        Assert.Contains($"<{TargetPages[1]}>", after.NextDirective);
    }

    [Fact]
    public void TargetCoverageMark_CannotBeReclassifiedAfterFirstMark()
    {
        var ledger = new SettingsCoverageLedger();

        Assert.True(ledger.TryMarkTargetReached(
            "Network & internet", TargetCoverageMarkKind.RouteEntered,
            decisionId: "decision-enter-1", route: "android.settings|route:Network"));
        Assert.False(ledger.TryMarkTargetSkipped(
            "Network & internet", "decision-skip-1", "later-skip"));

        Assert.Equal(TargetCoverageMarkKind.RouteEntered,
            ledger.TargetMarks["Network & internet"].Kind);
        Assert.Single(ledger.Events, item => item.Type == CoverageEventType.TargetCoverageMarked);
    }

    [Theory]
    [InlineData(TargetCoverageMarkKind.ReachedOverlay)]
    [InlineData(TargetCoverageMarkKind.RouteEntered)]
    public void ReachedNestedTarget_IsNotPendingOrDispatchedAgain(TargetCoverageMarkKind kind)
    {
        const string page = "android.settings|rk1:Mobile network|src=title|up=1";
        const string target = "SIM name & color";
        const string next = "Roaming";
        var config = BoundedConfig() with
        {
            DynamicNestedEntries = new DynamicNestedEntriesConfig(true, 1, 2),
        };
        var ledger = new SettingsCoverageLedger();
        Observe(ledger, RootRoute, TargetPages);
        Observe(ledger, page, target, next, BackDescriptor);
        Assert.Contains($"<{target}>", ledger.Snapshot(config).NextDirective);

        Assert.True(ledger.TryMarkTargetReached(target, kind, "decision-arrival", "android.settings"));

        Assert.DoesNotContain($"{page}>{target}", ledger.DynamicNestedFrontier(config));
        Assert.Contains($"{page}>{next}", ledger.DynamicNestedFrontier(config));
        Assert.Contains($"<{next}>", ledger.Snapshot(config).NextDirective);
        Assert.Contains(target, ledger.Report(config).ReachedTargets!);
        Assert.Empty(ledger.AgentSkippedTargets);
        Assert.False(ledger.TryMarkTargetSkipped(target, "decision-skip", "must not overwrite arrival"));
        Assert.Equal(kind, ledger.TargetMarks[target].Kind);
    }
}
