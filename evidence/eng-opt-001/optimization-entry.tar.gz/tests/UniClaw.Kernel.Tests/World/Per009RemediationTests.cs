using UniClaw.Kernel;
using UniClaw.Kernel.Assurance;
using UniClaw.Kernel.Control;
using UniClaw.Kernel.Diagnostics;
using UniClaw.Kernel.Effects;
using UniClaw.Kernel.Evidence;
using UniClaw.Kernel.Perception.UiHierarchy;
using UniClaw.Kernel.Run;
using UniClaw.Kernel.Runtime;
using UniClaw.Kernel.Trace;
using UniClaw.Kernel.World;
using UniClaw.Kernel.World.UiRealization;
using Xunit;

namespace UniClaw.Kernel.Tests.World;

/// <summary>
/// PER-009 评审整改回归（C-1/C-2/C-3/P-1）：权威域冲突销案且不升档（D13）、
/// 无 XML 侧/过期 dump/checkable guard 三剥夺路径（D3/D14/D12）、Run 边界
/// 复位、冻结信任表载入、事后验证四门 XML 路由。
/// </summary>
public sealed class Per009RemediationTests
{
    private static readonly DateTimeOffset T0 = new(2026, 9, 22, 12, 0, 0, TimeSpan.Zero);
    private static readonly TimeSpan Window = TimeSpan.FromSeconds(3);

    private sealed class DeterministicDriver : IEffectDriver
    {
        public DispatchResult Deliver(DispatchRequest request) =>
            new(DispatchOutcome.DeliveryCompleted, "test", T0);
    }

    private static UniKernel Compose(WorldModel world)
    {
        var traceScope = RunTraceFactory.BeginDisabled(new RunCorrelation("test:per009-fix"));
        return new UniKernel(
            new EvidenceLedger(), world, traceScope.Trace,
            new RunModel(), new ControlLoop(new AgentPlanPolicy()),
            new RuntimeAssurance(new ProductFreshnessEvaluator(() => T0, TimeSpan.FromMinutes(5))),
            new EffectBoundary(new DeterministicDriver()), new RuntimeStageMetrics());
    }

    private static ObservationProposal Claim(
        string subject, string value, string producer, DateTimeOffset capture,
        string[]? lineage = null) => new(
        new ObservationClaim(subject, value),
        IngressKind.Observation, ObservationContext.External,
        new Provenance(producer, capture, $"scope:{subject}", lineage ?? new[] { "test:claim" }));

    private static string SwitchState => "switch.state";

    private static void Observe(UniKernel kernel, ObservationProposal claim) =>
        kernel.Process(claim);

    [Fact]
    public void LegacyStateConflict_RemainsUnresolvedWithoutTypedSemanticEvidence()
    {
        var world = new WorldModel(new HashSet<string> { SwitchState });
        var kernel = Compose(world);

        Observe(kernel, Claim(SwitchState, "on", "host.live", T0)); // 视觉/系统侧：开
        Observe(kernel, Claim(SwitchState, "off", ProducerTrust.XmlProducer, T0,
            new[] { "xml-map:switch_widget", "xml-checkable:true", "xml-unique:true" })); // XML 定案：关
        Assert.Contains(world.Current!.Conflicts, c => c.Subject == SwitchState);

        var resolved = kernel.ResolveAuthorityConflicts(Window);

        // PER-014：legacy state conflict 没有 typed semantic.checked 证据时
        // 保持 unresolved；不再把 XML presentation 映射成 semantic authority。
        Assert.Equal(0, resolved);
        Assert.Contains(world.Current!.Conflicts, c => c.Subject == SwitchState);
        Assert.Empty(world.ConflictResolutionLog);
    }

    [Fact]
    public void NonXmlConflict_Stays_ForFocusedEscalation()
    {
        var world = new WorldModel(new HashSet<string> { SwitchState });
        var kernel = Compose(world);

        Observe(kernel, Claim(SwitchState, "on", "host.live", T0, new[] { "t:a" }));
        Observe(kernel, Claim(SwitchState, "off", "host.live", T0, new[] { "t:b" }));

        var resolved = kernel.ResolveAuthorityConflicts(Window);

        Assert.Equal(0, resolved); // 无 XML 侧：缺席即数据，不参战 → 交 Control 聚焦
        Assert.Contains(world.Current!.Conflicts, c => c.Subject == SwitchState);
    }

    [Fact]
    public void StaleDump_DeprivesAuthority_ConflictStays()
    {
        var world = new WorldModel(new HashSet<string> { SwitchState });
        var kernel = Compose(world);

        Observe(kernel, Claim(SwitchState, "on", "host.live", T0));
        Observe(kernel, Claim(SwitchState, "off", ProducerTrust.XmlProducer, T0 - TimeSpan.FromSeconds(30),
            new[] { "xml-map:x", "xml-checkable:true", "xml-unique:true" })); // 过期 dump

        var resolved = kernel.ResolveAuthorityConflicts(Window);

        Assert.Equal(0, resolved); // D14 FreshEnough：两份证据可能描述两个时刻
        Assert.Contains(world.Current!.Conflicts, c => c.Subject == SwitchState);
    }

    [Fact]
    public void CheckableFalse_GuardBlocks_Resolution()
    {
        var world = new WorldModel(new HashSet<string> { SwitchState });
        var kernel = Compose(world);

        Observe(kernel, Claim(SwitchState, "on", "host.live", T0));
        Observe(kernel, Claim(SwitchState, "off", ProducerTrust.XmlProducer, T0,
            new[] { "xml-map:x", "xml-checkable:false", "xml-unique:true" })); // guard 不过

        var resolved = kernel.ResolveAuthorityConflicts(Window);

        Assert.Equal(0, resolved); // D12：checkable=false 时 checked 不具权威
        Assert.Contains(world.Current!.Conflicts, c => c.Subject == SwitchState);
    }

    [Fact]
    public void ResolutionCarriesOccurrences_ActCanContinueWithoutReobservation()
    {
        // 销案 revision 原样携带 occurrences——Act 链不需观察恢复（机制闭环前提）
        var world = new WorldModel(
            new HashSet<string> { SwitchState, SharedSubjects.Screen, SharedSubjects.Frame },
            new ProductAssociationStrategy(),
            new HostSeededOccurrenceStrategy());
        var kernel = Compose(world);

        Observe(kernel, Claim(SharedSubjects.Screen, "s1", "host.live", T0));
        Observe(kernel, Claim(SwitchState, "on", "host.live", T0));
        Observe(kernel, Claim(SwitchState, "off", ProducerTrust.XmlProducer, T0,
            new[] { "xml-map:x", "xml-checkable:true", "xml-unique:true" }));
        // 帧批尾（revision-local occurrence 语义：承载 occurrence 的必须是最后一条）
        Observe(kernel, Claim(SharedSubjects.Frame, "{\"role\":\"switch\",\"state\":\"on\",\"b\":[0.1,0.1,0.2,0.2]}", "host.live", T0));
        var occurrencesBefore = world.Current!.Occurrences!.Count;
        Assert.True(occurrencesBefore > 0);

        kernel.ResolveAuthorityConflicts(Window);

        Assert.Equal(occurrencesBefore, world.Current!.Occurrences!.Count); // 携带不丢
        Assert.Contains(world.Current.Conflicts, c => c.Subject == SwitchState);
    }

    [Fact]
    public void FrozenTrustTable_Loads_AndMatchesDefault()
    {
        var frozen = ProducerTrust.LoadFrozenTable();

        Assert.Equal(ProducerTrust.Default().Lookup(ProducerTrust.XmlProducer, "state"),
            frozen.Lookup(ProducerTrust.XmlProducer, "state"));
        Assert.Equal(ProducerTrust.Grade.A, frozen.Lookup(ProducerTrust.XmlProducer, "state"));
        Assert.Equal(ProducerTrust.Grade.B, frozen.Lookup(ProducerTrust.XmlProducer, "bounds"));
        Assert.Equal(ProducerTrust.Grade.C, frozen.Lookup(ProducerTrust.VisionProducer, "state"));
        Assert.Equal(ProducerTrust.Grade.C, frozen.Lookup("unknown.producer", "state")); // 级联兜底
    }

    [Fact]
    public void TypedRoute_FourGates_VerifiesViaSemanticChecked()
    {
        // PER-014 R2：typed 验证路由四门等价回归（替代 legacy xml-route）。
        var typedSubject = "ui.node.cap-t1#0.checked";
        var world = new WorldModel(
            new HashSet<string> { SharedSubjects.Screen, SharedSubjects.Frame, typedSubject },
            new ProductAssociationStrategy(),
            new HostSeededOccurrenceStrategy(associateTyped: true));
        var kernel = Compose(world);

        Observe(kernel, Claim(SharedSubjects.Screen, "s1", "host.live", T0));
        Observe(kernel, Claim(SharedSubjects.Frame,
            "{\"role\":\"switch\",\"state\":\"on\",\"b\":[0.1,0.1,0.2,0.2]}", "host.live", T0));
        // typed claim 最后处理，使 occurrence 的 EvidenceBasis 显式携带
        // typed evidence；这是 S1 association seam 的测试输入。
        var post = kernel.Process(TypedCheckedClaim(typedSubject, "checked", T0.AddSeconds(1)));
        var target = new TargetSpec("switch", null, "tap", CheckedState.Checked);

        var verification = kernel.VerifyPostActionEffect(
            target, new[] { post }, dispatchTime: T0);

        Assert.True(verification.IsVerified);
        Assert.Contains(verification.Checks, c => c.Name == "typed-route-four-gates");
    }

    [Fact]
    public void TypedRoute_TemporalGate_Fails_FallsBackToOccurrencePath()
    {
        var typedSubject = "ui.node.cap-t2#0.checked";
        var world = new WorldModel(
            new HashSet<string> { SharedSubjects.Screen, SharedSubjects.Frame, typedSubject },
            new ProductAssociationStrategy(),
            new HostSeededOccurrenceStrategy(associateTyped: true));
        var kernel = Compose(world);

        Observe(kernel, Claim(SharedSubjects.Screen, "s1", "host.live", T0));
        Observe(kernel, Claim(SharedSubjects.Frame,
            "{\"role\":\"switch\",\"state\":\"on\",\"b\":[0.1,0.1,0.2,0.2]}", "host.live", T0));
        var post = kernel.Process(TypedCheckedClaim(typedSubject, "checked", T0.AddSeconds(1)));
        var target = new TargetSpec("switch", null, "tap", CheckedState.Unchecked);

        // 门④：capture 不在 dispatch 之后 → 语义权威域证据不足；禁止
        // 退回 occurrence 视觉路径。
        var verification = kernel.VerifyPostActionEffect(
            target, new[] { post }, dispatchTime: T0 + TimeSpan.FromSeconds(1));

        Assert.False(verification.IsVerified);
        Assert.Contains(verification.Checks, c => c.Name == "typed-route-four-gates" && !c.Passed);
        Assert.Contains("insufficient-evidence", verification.RejectionReason);
    }

    [Fact]
    public void TypedRoute_UnknownWithVisualOff_DoesNotBecomeUnchecked()
    {
        var world = new WorldModel(
            new HashSet<string> { SharedSubjects.Screen, SharedSubjects.Frame },
            new ProductAssociationStrategy(),
            new HostSeededOccurrenceStrategy("off", associateTyped: true));
        var kernel = Compose(world);
        Observe(kernel, Claim(SharedSubjects.Screen, "s1", "host.live", T0));
        var post = kernel.Process(Claim(SharedSubjects.Frame,
            "{\"role\":\"switch\",\"state\":\"off\",\"b\":[0.1,0.1,0.2,0.2]}", "host.live", T0.AddSeconds(1)));

        var verification = kernel.VerifyPostActionEffect(
            new TargetSpec("switch", null, "tap", CheckedState.Unchecked),
            new[] { post }, dispatchTime: T0);

        Assert.False(verification.IsVerified);
        Assert.Contains("no-checked-claim", verification.RejectionReason);
    }

    [Fact]
    public void TypedRoute_UnsupportedWithVisualOn_DoesNotBecomeChecked()
    {
        var typedSubject = "ui.node.cap-s2-unsupported#0.checked";
        var world = new WorldModel(
            new HashSet<string> { SharedSubjects.Screen, SharedSubjects.Frame, typedSubject },
            new ProductAssociationStrategy(),
            new HostSeededOccurrenceStrategy("on", associateTyped: true));
        var kernel = Compose(world);
        Observe(kernel, Claim(SharedSubjects.Screen, "s1", "host.live", T0));
        Observe(kernel, Claim(SharedSubjects.Frame,
            "{\"role\":\"switch\",\"state\":\"on\",\"b\":[0.1,0.1,0.2,0.2]}", "host.live", T0));
        var typed = kernel.Process(TypedCheckedClaim(
            typedSubject, "checked", T0.AddSeconds(1), HierarchyCapability.None));

        var verification = kernel.VerifyPostActionEffect(
            new TargetSpec("switch", null, "tap", CheckedState.Checked),
            new[] { typed }, dispatchTime: T0);

        Assert.False(verification.IsVerified);
        Assert.Contains("capability:checked-absent", verification.RejectionReason);
    }

    [Fact]
    public void TypedRoute_PartialWithVisualOff_IsInsufficient()
    {
        var typedSubject = "ui.node.cap-s2-partial#0.checked";
        var world = new WorldModel(
            new HashSet<string> { SharedSubjects.Screen, SharedSubjects.Frame, typedSubject },
            new ProductAssociationStrategy(),
            new HostSeededOccurrenceStrategy("off", associateTyped: true));
        var kernel = Compose(world);
        Observe(kernel, Claim(SharedSubjects.Screen, "s1", "host.live", T0));
        Observe(kernel, Claim(SharedSubjects.Frame,
            "{\"role\":\"switch\",\"state\":\"off\",\"b\":[0.1,0.1,0.2,0.2]}", "host.live", T0));
        var typed = kernel.Process(TypedCheckedClaim(
            typedSubject, "partial", T0.AddSeconds(1), HierarchyCapability.CheckedTriState));

        var verification = kernel.VerifyPostActionEffect(
            new TargetSpec("switch", null, "tap", CheckedState.Unchecked),
            new[] { typed }, dispatchTime: T0);

        Assert.False(verification.IsVerified);
        Assert.Contains("insufficient-evidence", verification.RejectionReason);
    }

    [Fact]
    public void TypedRoute_CheckedWithVisualOff_UsesTypedAuthority()
    {
        var typedSubject = "ui.node.cap-s2-checked#0.checked";
        var world = new WorldModel(
            new HashSet<string> { SharedSubjects.Screen, SharedSubjects.Frame, typedSubject },
            new ProductAssociationStrategy(),
            new HostSeededOccurrenceStrategy("off", associateTyped: true));
        var kernel = Compose(world);
        Observe(kernel, Claim(SharedSubjects.Screen, "s1", "host.live", T0));
        Observe(kernel, Claim(SharedSubjects.Frame,
            "{\"role\":\"switch\",\"state\":\"off\",\"b\":[0.1,0.1,0.2,0.2]}", "host.live", T0));
        var typed = kernel.Process(TypedCheckedClaim(
            typedSubject, "checked", T0.AddSeconds(1)));

        var verification = kernel.VerifyPostActionEffect(
            new TargetSpec("switch", null, "tap", CheckedState.Checked),
            new[] { typed }, dispatchTime: T0);

        Assert.True(verification.IsVerified);
        Assert.Contains(verification.Checks, c => c.Name == "typed-route-four-gates");
    }

    [Fact]
    public void TypedRoute_MissingDispatchTime_IsInsufficientNotVisual()
    {
        var world = new WorldModel(
            new HashSet<string> { SharedSubjects.Screen, SharedSubjects.Frame },
            new ProductAssociationStrategy(),
            new HostSeededOccurrenceStrategy("off"));
        var kernel = Compose(world);
        Observe(kernel, Claim(SharedSubjects.Screen, "s1", "host.live", T0));
        var post = kernel.Process(Claim(SharedSubjects.Frame,
            "{\"role\":\"switch\",\"state\":\"off\",\"b\":[0.1,0.1,0.2,0.2]}", "host.live", T0.AddSeconds(1)));

        var verification = kernel.VerifyPostActionEffect(
            new TargetSpec("switch", null, "tap", CheckedState.Unchecked),
            new[] { post });

        Assert.False(verification.IsVerified);
        Assert.Contains("dispatch-time-missing", verification.RejectionReason);
    }

    [Fact]
    public void NullDesiredState_StillUsesVisualVerification()
    {
        var world = new WorldModel(
            new HashSet<string> { SharedSubjects.Screen, SharedSubjects.Frame },
            new ProductAssociationStrategy(),
            new HostSeededOccurrenceStrategy("off"));
        var kernel = Compose(world);
        Observe(kernel, Claim(SharedSubjects.Screen, "s1", "host.live", T0));
        var post = kernel.Process(Claim(SharedSubjects.Frame,
            "{\"role\":\"switch\",\"state\":\"off\",\"b\":[0.1,0.1,0.2,0.2]}", "host.live", T0.AddSeconds(1)));

        var verification = kernel.VerifyPostActionEffect(
            new TargetSpec("switch", null, "tap"), new[] { post }, dispatchTime: T0);

        Assert.True(verification.IsVerified);
        Assert.DoesNotContain(verification.Checks, c => c.Name == "typed-route-four-gates");
    }

    [Fact]
    public void NavigationTargetDisappearance_AfterRouteFingerprintChange_IsVerified()
    {
        var world = new WorldModel(
            new HashSet<string>
            {
                ProductAssociationStrategy.ScreenIdentitySubject,
                ProductAssociationStrategy.ScreenRouteSubject,
            },
            new ProductAssociationStrategy(), new NavigationOccurrenceStrategy());
        var kernel = Compose(world);

        Observe(kernel, ScreenClaim("android.settings", T0, ObservationContext.External));
        Observe(kernel, ScreenRouteClaim("android.settings|route:Settings", T0,
            ObservationContext.External));
        var before = kernel.CurrentBelief!;
        Assert.Single(before.Occurrences!);
        Assert.Equal("Network & internet", before.Occurrences![0].SemanticDescriptor);

        var post = kernel.Process(ScreenRouteClaim("android.settings|route:Network", T0.AddSeconds(1),
            ObservationContext.PostActionEffectFlow));
        Assert.Equal("android.settings|route:Settings",
            before.WorldState[ProductAssociationStrategy.ScreenRouteSubject].Value);
        Assert.Equal("android.settings|route:Network",
            kernel.CurrentBelief!.WorldState[ProductAssociationStrategy.ScreenRouteSubject].Value);
        var verification = kernel.VerifyPostActionEffect(
            new TargetSpec("ui.element", "Network & internet", "tap"),
            new[] { post }, T0, before);

        Assert.True(verification.IsVerified,
            $"reason={verification.RejectionReason}; checks={string.Join(',', verification.Checks.Select(c => c.Name + "=" + c.Passed))}");
        Assert.Contains(verification.Checks,
            check => check.Name == "post-action-navigation-transition" && check.Passed);
    }

    private static ObservationProposal ScreenClaim(
        string value, DateTimeOffset capture, ObservationContext context) => new(
        new ObservationClaim(ProductAssociationStrategy.ScreenIdentitySubject, value),
        IngressKind.Observation, context,
        new Provenance("host.live.settings", capture, "scope:ui.screen",
            new[] { "real-device", "screen-identity" }));

    private static ObservationProposal ScreenRouteClaim(
        string value, DateTimeOffset capture, ObservationContext context) => new(
        new ObservationClaim(ProductAssociationStrategy.ScreenRouteSubject, value),
        IngressKind.Observation, context,
        new Provenance("host.live.settings", capture,
            "scope:ui.screen.route:" + capture.ToUnixTimeMilliseconds(),
            new[] { "real-device", "route-fingerprint" }));

    private sealed class NavigationOccurrenceStrategy : IUiObservationStrategy
    {
        public IReadOnlyList<ProposedOccurrence> Derive(
            EvidenceRecord record, WorldBeliefRevision? previous)
        {
            if (record.Claim.Subject != ProductAssociationStrategy.ScreenRouteSubject)
                return previous?.Occurrences?.Select(o => new ProposedOccurrence(
                    o.OwningContainerId, o.Role, o.SemanticDescriptor, o.State,
                    o.Locator, o.Native, o.Space)).ToArray()
                    ?? Array.Empty<ProposedOccurrence>();
            var descriptor = record.Claim.Value.EndsWith("route:Settings", StringComparison.Ordinal)
                ? "Network & internet"
                : "Internet";
            var owner = previous?.Containers is { Count: 1 } containers
                ? containers[0].Identity.ContainerId
                : null;
            return new[]
            {
                new ProposedOccurrence(owner, "ui.element", descriptor, null,
                    new SpatialLocator(0.1, 0.1, 0.9, 0.2, "test.frame")),
            };
        }
    }

    /// <summary>typed checked claim（PER-013 投影同构：occurrence-qualified
    /// subject + Hierarchy descriptor provenance，capture timestamp 可控）。</summary>
    private static ObservationProposal TypedCheckedClaim(
        string subject, string value, DateTimeOffset captureTime,
        HierarchyCapability capabilities = HierarchyCapability.CheckedBooleanCollapsed) => new(
        new ObservationClaim(subject, value),
        IngressKind.Observation, ObservationContext.PostActionEffectFlow,
        new Provenance(
            TypedHierarchyProposalProjector.Producer, captureTime, $"scope:{subject}",
            new[] { TypedHierarchyProposalProjector.LineageMarker },
            Hierarchy: new HierarchyCaptureDescriptor(
                CaptureId: NodeCaptureId(subject), AndroidApiLevel: 34,
                UiHierarchyAcquirerKind.LegacyUiAutomatorXml, "1.0",
                UiHierarchyFormat.UiAutomatorXml, "dev-1", "sess-1",
                ObservationCycleId: null, CaptureTimestamp: captureTime,
                CaptureDuration: null, capabilities,
                CoverageCompleteness.CompleteWithinDeclaredSurface,
                CoverageLimitation: null, NodeLocalIndex: NodeLocalIndex(subject), ParentLocalIndex: null,
                Field: "checked")));

    private static string NodeCaptureId(string subject)
    {
        var body = subject["ui.node.".Length..];
        return body[..body.LastIndexOf('#')];
    }

    private static int NodeLocalIndex(string subject)
    {
        var body = subject["ui.node.".Length..];
        var hash = body.LastIndexOf('#');
        var dot = body.LastIndexOf('.');
        return int.Parse(body[(hash + 1)..dot], System.Globalization.CultureInfo.InvariantCulture);
    }

    /// <summary>测试侧 occurrence 策略：从 screen.frame 帧派生 switch occurrence。</summary>
    private sealed class HostSeededOccurrenceStrategy(string state = "on", bool associateTyped = false) : IUiObservationStrategy
    {
        public IReadOnlyList<ProposedOccurrence> Derive(EvidenceRecord record, WorldBeliefRevision? previous)
        {
            if (record.Claim.Subject != SharedSubjects.Frame
                && !(associateTyped && record.Claim.Subject.StartsWith("ui.node.", StringComparison.Ordinal)))
                return Array.Empty<ProposedOccurrence>();
            var owner = previous?.Containers.Count == 1 ? previous.Containers[0].Identity.ContainerId : null;
            return new[]
            {
                new ProposedOccurrence(owner, "switch", null, state,
                    new SpatialLocator(0.1, 0.1, 0.2, 0.2, "test.frame")),
            };
        }
    }
}
