using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using UniClaw.Kernel;
using UniClaw.Kernel.Assurance;
using UniClaw.Kernel.Control;
using UniClaw.Kernel.Diagnostics;
using UniClaw.Kernel.Effects;
using UniClaw.Kernel.Effects.ExecutionSource;
using UniClaw.Kernel.Evidence;
using UniClaw.Kernel.Run;
using UniClaw.Kernel.Perception;
using UniClaw.Kernel.Runtime;
using UniClaw.Kernel.Trace;
using UniClaw.Kernel.World;
using UniClaw.Kernel.World.UiRealization;
using UniClaw.Host.Capability;
using UniClaw.Host.Runtime;

namespace UniClaw.Host.SettingsCoverage;

/// <summary>
/// AGT-005 — 可配置、有界、可追溯的 Settings 菜单覆盖遍历 runner。
/// 单 Kernel run + director 包装 ConsultAgent；bounds/coverage/targets/
/// termination 全部来自 SettingsCoverageConfig（不写死在逻辑中）。
/// 逐步 trace 经 NextInput 包装缝交错记账（receipts↔routes 按观察拉取点
/// 配对；receipts↔verifications 按派发序配对；DecisionId/Directive 按
/// (role,descriptor,effect) 元组 FIFO 归属——grounding 失败的采纳步骤
/// 不产生 receipt，不参与账本 executed 记账），产物 coverage-steps.json +
/// coverage-report.json + 既有 trace/facts/settings-trace。
/// </summary>
public sealed class SettingsCoverageRunner
{
    /// <summary>
    /// TRAJECTORY-001 D3 裁决的停滞判定纯函数：进度指纹 (已进入/到达目标数,
    /// frontier) 与上一快照相等 = 覆盖事实无推进，停滞计数 +1。不含
    /// StepsVerified（弹窗循环里每个清障 tap 都"验证成功"，恒涨）；也不比较
    /// 证据指纹（present/absent 交替会每轮清零计数器）。首快照（prior=null）
    /// 不算停滞。
    /// </summary>
    internal static bool ShouldIncrementStagnation(
        (int Entered, int Frontier)? prior,
        (int Entered, int Frontier) current) =>
        prior is { } snapshot && snapshot == current;

    public sealed record Options(
        string DeviceId,
        LivePerception.LiveAssets Live,
        SettingsCoverageConfig Config,
        Func<AgentDecisionContext, AgentDecision?> UnderlyingConsult,
        int? ViewportWidth = null,
        int? ViewportHeight = null,
        Func<string?>? DshSessionIdAccessor = null,
        // 测试缝（确定性场景认证用）：默认 null = SettingsTraversalLiveFeed
        // + AdbLiveEffectDriver（真实档）。
        Func<ObservationDirective, RunDriverInput?>? FeedNext = null,
        Func<string?>? CurrentCaptureId = null,
        IEffectDriver? EffectDriver = null,
        // PER-019：UniPerception fetch 缝（透传 feed 异步流水；null = slow 关闭）。
        UniPerceptionPipeline.Fetch? SlowConsult = null,
        // CAP-013：任务要求与可选 agent 选择；缺失 = 本次不加载语言检查。
        LanguageInspectionTaskRequest? LanguageInspection = null,
        LanguageInspectionSelection? LanguageInspectionSelection = null,
        Func<LanguageInspectionSelection?>? LanguageInspectionSelectionProvider = null,
        UniClaw.Kernel.Capability.CapabilityRegistry? RuntimeIntegrationCapabilities = null,
        // 认知测试缝：false 时直接采用 UnderlyingConsult 的建议，仍经同一
        // Kernel grounding/assurance/effect 链；默认 true 保持 coverage director。
        bool UseCoverageDirector = true,
        Func<RunDriverInput.Cancel?>? PollCancellation = null);

    public sealed record StepArtifact(
        int Index,
        string DecisionId,
        string? DshSessionId,
        string? Directive,
        string TargetRole,
        string? TargetDescriptor,
        string EffectClass,
        string? DesiredState,
        bool PreActionTargetUnique,
        string? ReceiptId,
        string? ReceiptOutcome,
        string? ReceiptCommand,
        string? RouteBefore,
        string? RouteAfter,
        string? PostCaptureId,
        bool Verified,
        string? FailureReason,
        IReadOnlyList<KeyValuePair<string, bool>> Checks);

    public sealed record RunResult(
        string RunDir,
        RunDriveStatus Status,
        string? Reason,
        string? Outcome,
        CoverageReport Report,
        IReadOnlyList<StepArtifact> Steps,
        IReadOnlyList<SettingsCoverageDirector.ConsultRecord> Consults,
        IReadOnlyList<string> DshDiagnostics,
        string FactsDigest);

    private sealed record ConsultBridgeRecord(
        string Mode,
        AgentDecisionContext Context,
        ConsultDecisionArtifact? Decision,
        ConsultDecisionArtifact? EffectiveDecision);

    private sealed record ConsultDecisionArtifact(
        string Kind,
        string? Justification,
        IReadOnlyList<AgentActionStep> Steps,
        string? SkipTarget = null,
        string? SkipReason = null,
        IReadOnlyList<string>? EvidenceRefs = null,
        BudgetRenewalRequest? Renewal = null,
        BudgetReviewResponse? ReviewResponse = null);

    public static RunResult Run(string runRoot, Options options) =>
        RunAsync(runRoot, options).GetAwaiter().GetResult();

    /// <summary>One continuous execution; handler waits yield without turning
    /// into new consultations or discarding the driver's current position.</summary>
    public static async Task<RunResult> RunAsync(
        string runRoot, Options options, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(runRoot);
        ArgumentNullException.ThrowIfNull(options);
        var config = options.Config;
        if (config.ActionPolicyRequired && config.ActionPolicy is null)
            throw new InvalidOperationException(
                "PROFILE_CONTRACT_NOT_READY: required Settings action policy is not loaded");
        Directory.CreateDirectory(runRoot);
        var runDir = Path.Combine(runRoot, $"run-{DateTimeOffset.UtcNow:yyyyMMdd-HHmmss-fff}");
        Directory.CreateDirectory(runDir);
        var journalPath = Path.Combine(runDir, "exec.journal");

        var clock = new HostUtilities.VirtualClock();
        var scope = new HashSet<string>
        {
            ProductAssociationStrategy.ScreenIdentitySubject,
            ProductAssociationStrategy.ScreenRouteSubject,
            ProductAssociationStrategy.PopupSubject, // AGT-009：弹窗 typed 声明
            SharedSubjects.Frame,
            "ui.node.*",
        };
        var ledger = new SettingsCoverageLedger();
        var evidenceSettings = config.EvidenceSettings;
        var evidenceDir = options.FeedNext is null
            ? Path.Combine(runDir, "evidence")
            : null;
        var acquisitionPreflight = System.Diagnostics.Stopwatch.StartNew();
        var liveFeed = options.FeedNext is null
            ? new SettingsTraversalLiveFeed(
                clock, options.Live, evidenceDir,
                evidenceSettings.PersistScreenshots, evidenceSettings.PersistHierarchies,
                coverageConfig: config, uniPerceptionFetch: options.SlowConsult)
            : null;
        acquisitionPreflight.Stop();
        if (liveFeed is not null)
            WriteText(runDir, "environment-preflight.json", TryJson(new
            {
                schemaVersion = "uniclaw.environment-preflight.v1",
                visionServiceWarmup = liveFeed.EnvironmentPreflight,
                preflightElapsedMilliseconds = acquisitionPreflight.Elapsed.TotalMilliseconds,
                formalFlowStartedAfterPreflight = true,
            }));
        var feedNext = options.FeedNext ?? liveFeed!.Next;
        var currentCaptureId = options.CurrentCaptureId
            ?? (liveFeed is not null ? () => liveFeed.Trace.Count > 0 ? liveFeed.Trace[^1].CaptureId : null : () => null);
        UniKernel? kernel = null;
        var journal = new CoverageStepJournal(
            ledger,
            () => kernel?.PostActionVerifications
                ?? (IReadOnlyList<PostActionEffectVerification>)Array.Empty<PostActionEffectVerification>(),
            options.DshSessionIdAccessor);
        var director = new SettingsCoverageDirector(
            options.UnderlyingConsult, ledger, config, journal,
            // AGT-019 M2-②/B3 seam：诊断/视口从感知管线最新周期流入
            // Director 装饰层（LocalView 四族补缺闭环）。
            localViewSources: liveFeed is null ? null : () => (liveFeed.LatestDiagnostics, liveFeed.LatestViewport),
            // TRAJECTORY-001 D2：对话框标题从感知管线最新周期流入 Director
            // （到达即完成判据）。
            dialogTitleSource: liveFeed is null ? null : () => liveFeed.LatestDialogTitle);
        var consultBridge = new List<ConsultBridgeRecord>();
        try
        {
            var world = new WorldModel(
                scope,
                new ProductAssociationStrategy(),
                new UiHierarchyOccurrenceStrategy());
            var assurance = new RuntimeAssurance(
                new ProductFreshnessEvaluator(() => clock.Now, TimeSpan.FromMinutes(5)));
            IEffectDriver delivery = options.EffectDriver ?? new AdbLiveEffectDriver(
                options.DeviceId,
                options.ViewportWidth,
                options.ViewportHeight,
                adbExecutable: "adb",
                clock: () => clock.Now);
            var effectBoundary = new EffectBoundary(delivery, new FileExecutionJournal(journalPath));
            var metrics = new RuntimeStageMetrics();
            var planPolicy = new AgentPlanPolicy
            {
                // The existing policy caps cumulative *additional* grants;
                // task configuration declares the final total, including the initial budget.
                HardCapTotalSteps = config.Bounds.MaxTotalSteps - config.Bounds.MaxSteps,
                HardCapConsultations = config.Bounds.MaxTotalConsultRounds - config.Bounds.MaxConsultRounds,
                RenewalThresholdSteps = config.Bounds.RenewalThresholdSteps,
                RenewalThresholdRounds = config.Bounds.RenewalThresholdRounds,
                GoalDirectedContinuationEnabled = config.Bounds.GoalDirectedContinuationEnabled,
                AuthorizedTotalSteps = config.Bounds.AuthorizedTotalSteps,
                AuthorizedTotalConsultRounds = config.Bounds.AuthorizedTotalConsultRounds,
            };
            var traceScope = RunTraceFactory.BeginRun(new RunCorrelation("host:v0-settings-coverage"));
            var evidenceLedger = new EvidenceLedger();
            kernel = new UniKernel(
                evidenceLedger, world, traceScope.Trace,
                new RunModel(), new ControlLoop(planPolicy), assurance, effectBoundary, metrics);

            // ---- NextInput 包装缝：观察/回执交错记账 -----------------------
            LanguageInspectionPostCommit? languageInspection = null;
            LanguageInspectionBinding? traversalLanguageBinding = null;
            var capabilityProfilesInjected = false;
            void TryBindLanguageInspection()
            {
                if (languageInspection is not null)
                    return;
                var selection = options.LanguageInspectionSelection
                    ?? options.LanguageInspectionSelectionProvider?.Invoke();
                var request = options.LanguageInspection ?? config.LanguageInspectionRequest;
                if (request is null)
                    return;
                if (selection is null && string.IsNullOrWhiteSpace(request.FixedCapabilityId))
                    return;
                var binding = LanguageInspectionBindingFactory.Create(
                    options.RuntimeIntegrationCapabilities,
                    kernel.RunId,
                    request,
                    selection);
                traversalLanguageBinding = binding;
                if (binding is not null)
                    languageInspection = new LanguageInspectionPostCommit(
                        binding, Path.Combine(runDir, "language-findings.json"));
            }
            var traversalInspection = new TraversalLanguageInspection(kernel, evidenceLedger, () =>
            {
                TryBindLanguageInspection();
                var lifecycle = options.RuntimeIntegrationCapabilities?.Facts.LastOrDefault(fact =>
                    fact.CapabilityId == UniClaw.Kernel.Capability.LanguageInspectionProtocol.CapabilityId)?.Lifecycle;
                return lifecycle is UniClaw.Kernel.Capability.CapabilityLifecycle.Registered
                    or UniClaw.Kernel.Capability.CapabilityLifecycle.Ready
                    or UniClaw.Kernel.Capability.CapabilityLifecycle.Active
                        ? traversalLanguageBinding : null;
            });
            var materializedSteps = new List<(string DecisionId, string? Directive, AgentActionStep Step)>();
            var interleave = new InterleaveBookkeeper(
                kernel,
                feedNext,
                currentCaptureId,
                ledger,
                journal,
                config,
                TryBindLanguageInspection,
                () => languageInspection,
                () => journal.Drain(materializedSteps));
            director.SyncBeforeSnapshot = interleave.SyncNow;
            // AGT-009：feed 的有界 Slow 咨询投影目标 = 当前 run kernel。
            if (liveFeed is not null)
                liveFeed.KernelProvider = () => kernel;
            using var consultationJournal = new FileConsultationJournal(Path.Combine(runDir, "consultations.journal.jsonl"));
            var currentStepGuards = new List<object>();
            var candidateProjections = new List<object>();
            director.CurrentStepGuardInstalled = true;
            var driver = new KernelRunDriver(
                kernel, planPolicy,
                new RunDriverInputs
                {
                    NextInput = interleave.WrappedNext,
                    PollCancellation = options.PollCancellation,
                    ConsultationJournal = consultationJournal,
                    AvailablePlanSources = SettingsPlanFacts.SourceDescriptions.Concat(new[]
                    {
                        new KeyValuePair<string, string>(SettingsTraversalProjection.Source,
                            SettingsTraversalProjection.Describe(config)),
                    }).ToDictionary(item => item.Key, item => item.Value, StringComparer.Ordinal),
                    ProjectTraversal = source => SettingsTraversalProjection.Project(source, kernel, config),
                    CanBindPlanLanguage = traversalInspection.CanBind,
                    InspectPlanLanguage = traversalInspection.Inspect,
                    InspectPlanLanguageAsync = traversalInspection.InspectAsync,
                    ObserveTraversalRecovery = facts => WriteText(runDir, "traversal-recovery.json", TryJson(facts)),
                    AvailablePlanConditions = SettingsPlanFacts.ConditionDescriptions,
                    EvaluatePlanCondition = (condition, _) =>
                    {
                        journal.Drain(materializedSteps);
                        interleave.SyncNow();
                        return SettingsPlanFacts.EvaluateCondition(condition, ledger, config);
                    },
                    ProjectPlanCandidates = source =>
                    {
                        journal.Drain(materializedSteps);
                        interleave.SyncNow();
                        var facts = SettingsPlanFacts.Project(source, ledger, config);
                        candidateProjections.Add(new { source, facts });
                        return facts;
                    },
                    GuardStep = (step, context) =>
                    {
                        journal.Drain(materializedSteps);
                        interleave.SyncNow();
                        var constraint = config.NavigationScope is not null || config.ActionPolicy is not null
                            ? SettingsActionGuard.EvaluateCurrentStep(step, context, config)
                            : new PlanStepGuardResult(PlanStepGuardVerdict.Allow, "no additional Settings policy configured");
                        constraint = constraint with
                        {
                            EvidenceRefs = (constraint.EvidenceRefs ?? Array.Empty<string>())
                                .Concat(kernel.CurrentBelief?.EvidenceBasis.AsEnumerable() ?? Enumerable.Empty<string>())
                                .Distinct(StringComparer.Ordinal).ToArray(),
                        };
                        currentStepGuards.Add(new { context.DecisionId, step, constraint, context.Screen });
                        if (constraint.Verdict == PlanStepGuardVerdict.Allow)
                            materializedSteps.Add((context.DecisionId,
                                options.UseCoverageDirector ? director.ConsultLog.LastOrDefault()?.Directive : null, step));
                        return constraint;
                    },
                    CheckTaskEvidenceBarrier = config.Bounds.GoalDirectedContinuationEnabled
                        ? () =>
                        {
                            journal.Drain(materializedSteps);
                            interleave.SyncNow();
                            var report = ledger.Report(config);
                            return report.UncoveredItems.Count == 0 ? null
                                : string.Join(",", report.UncoveredItems);
                        }
                        : null,
                    ProjectExecutionOverview = () =>
                    {
                        // Flush accepted observation/verification facts before projecting;
                        // Agent, audit history and final report consume this same snapshot.
                        // Preserve receipt/verification -> post-observation
                        // ordering. Discovery after a verified swipe depends on
                        // this same ledger sequence, as does review freshness.
                        journal.Drain(materializedSteps);
                        interleave.SyncNow();
                        var projection = SettingsCoverageOverviewProjector.Project(ledger, config);
                        var graph = kernel.ProjectWorldGraph($"{kernel.RunId}:{kernel.RunView?.Version}");
                        var navigationFacts = graph?.Edges.Select(edge =>
                            $"navigation:{edge.SourceContainerId}>{edge.TargetContainerId}").ToArray()
                            ?? Array.Empty<string>();
                        var actionableItems = projection.ActionableItems?.ToDictionary(
                            entry => entry.Key, entry => entry.Value, StringComparer.Ordinal);
                        if (actionableItems?.TryGetValue("explore:unobserved-scope", out var exploration) == true)
                            actionableItems["explore:unobserved-scope"] = exploration with
                            {
                                ProgressFactKeys = exploration.ProgressFactKeys.Concat(navigationFacts)
                                    .Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal).ToArray(),
                            };
                        return projection with
                        {
                            WorldGraph = graph,
                            ActionableItems = actionableItems,
                            ProgressFactKeys = (projection.ProgressFactKeys ?? Array.Empty<string>())
                                .Concat(navigationFacts)
                                .Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal).ToArray(),
                        };
                    },
                    MarkTargetCoverage = request =>
                    {
                        // Agent Skip is a zero-Effect owner mark. Duplicate or
                        // already-marked targets are idempotent at the ledger.
                        ledger.TryMarkTargetSkipped(
                            request.Target,
                            request.DecisionId,
                            request.Reason,
                            request.EvidenceRefs);
                    },
                    ConsultAgent = context =>
                    {
                        var projected = context;
                        if (!capabilityProfilesInjected)
                        {
                            projected = projected with
                            {
                                AvailableCapabilities =
                                    RuntimeIntegrationCapabilityComposition.DescribeAvailableProfiles(
                                        options.RuntimeIntegrationCapabilities),
                            };
                            capabilityProfilesInjected = true;
                        }
                        var rawDecision = options.UseCoverageDirector
                            ? director.Consult(projected)
                            : options.UnderlyingConsult(projected);
                        var decision = rawDecision;
                        if (!options.UseCoverageDirector)
                        {
                            journal.Drain(materializedSteps);
                            interleave.SyncNow();
                            decision = director.RecordAdvisoryDecision(projected, decision);
                        }
                        consultBridge.Add(new ConsultBridgeRecord(
                            options.UseCoverageDirector ? "coverage-director" : "advisory-direct",
                            projected,
                            ToConsultArtifact(rawDecision),
                            ToConsultArtifact(decision)));
                        // Bind task initialization before the returned plan or
                        // instruction payload reaches Kernel execution.
                        TryBindLanguageInspection();
                        return decision;
                    },
                });

            var admission = kernel.AdmitContract(new ExecutionContract(
                Version: "v0",
                Objective: "Traverse Android Settings within the current device, account, permissions and system state. "
                    + "Enter every configured first-level target: " + string.Join("; ", config.TargetPages) + ". "
                    + $"Required evidence: rootPage={config.Coverage.RootPage}, "
                    + $"scrollDiscoveredEntries={config.Coverage.ScrollDiscoveredEntries}, "
                    + $"secondLevelPages={config.Coverage.SecondLevelPages}, "
                    + $"backNavigation={config.Coverage.BackNavigation}, repeatedEntries={config.Coverage.RepeatedEntries}. "
                    + (config.DynamicRootEntriesSettings.AllVisible
                        ? "Discover and inspect the safe dynamic root frontier; keep unobserved branches unknown. " : "")
                    + (config.DynamicNestedEntriesSettings.IsActive
                        ? "Inspect the configured dynamic nested frontier, keeping depth and scope limits explicit. " : "")
                    + "End on the observed Settings root. Select every action from the current semantic hierarchy. "
                    + "A configured scope result never proves all possible UI states exhaustive.",
                Scope: scope,
                AllowedEffects: new HashSet<string>(StringComparer.Ordinal) { "tap", "swipe-up" },
                ForbiddenEffects: config.ActionPolicy is { } actionPolicy
                    ? new HashSet<string>(actionPolicy.ForbiddenActionClasses, StringComparer.OrdinalIgnoreCase)
                    : new HashSet<string>(StringComparer.Ordinal),
                ProofCriteria: new[] { "settings-coverage" },
                Obligations: new[]
                {
                    new RunObligation(
                        "obj-end-on-root", RunObligationKind.Objective,
                        Subject: ProductAssociationStrategy.ScreenRouteSubject,
                        RequiredValue: config.RootRoute,
                        Mandatory: true),
                },
                MaxConsultations: config.Bounds.MaxConsultRounds,
                MaxTotalSteps: config.Bounds.MaxSteps,
                TaskInstanceId: "task-settings-coverage",
                ProductSessionId: "session-settings-coverage",
                ContractRef: "contract-settings-coverage",
                AcceptedContractViewRef: "view-settings-coverage",
                ContractGeneration: 1));
            if (!admission.Accepted)
                throw new InvalidOperationException($"contract rejected: {admission.RejectionReason}");

            var languageInspectionRequest =
                options.LanguageInspection ?? config.LanguageInspectionRequest;
            if (languageInspectionRequest is not null)
            {
                TryBindLanguageInspection();
            }

            driver.Activate();
            RunDriveResult drive = default!;
            // Semantic/resource limits are enforced by Runtime. A second loop
            // cap computed from the initial grant would silently undo renewal.
            while (true)
            {
                drive = await driver.DriveAsync(cancellationToken).ConfigureAwait(false);
                if (drive.Status is not RunDriveStatus.WaitingForInput)
                    break;
            }
            interleave.FlushObservation();
            WriteText(
                runDir,
                "coverage-events.jsonl",
                string.Join(
                    Environment.NewLine,
                    ledger.Events.Select(eventRecord => JsonSerializer.Serialize(eventRecord, JsonOptions)))
                + Environment.NewLine);
            TryBindLanguageInspection();
            if (languageInspectionRequest is { Required: true } && languageInspection is null)
                throw new InvalidOperationException("language-inspection-required-capability-not-bound");
            journal.Drain(materializedSteps);

            // ---- 产物落盘 ---------------------------------------------------
            WriteText(runDir, "trace.json", TryJson(traceScope.FinalizeArtifact()));
            if (liveFeed is not null)
                WriteText(runDir, "settings-trace.json", TryJson(liveFeed.Trace));

            var receipts = kernel.EffectReceipts;
            var steps = journal.Artifacts();
            var report = ledger.Report(config);
            WriteText(runDir, "coverage-steps.json", TryJson(steps));
            WriteText(runDir, "plan-execution.json", TryJson(driver.PlanExecution));
            WriteText(runDir, "traversal-execution.json", TryJson(kernel.TraversalExecution));
            WriteText(runDir, "plan-candidate-projections.json", TryJson(candidateProjections));
            WriteText(runDir, "current-step-guards.json", TryJson(currentStepGuards));
            WriteText(runDir, "coverage-report.json", TryJson(report));
            WriteText(runDir, "coverage-observed-elements.json", TryJson(ledger.ObservedElements));
            WriteText(runDir, "world-navigation.json", TryJson(
                kernel.ProjectWorldGraph($"{kernel.RunId}:{kernel.RunView?.Version}")));
            WriteText(runDir, "execution-overviews.json", TryJson(
                consultBridge.Select(exchange => new
                {
                    exchange.Context.DecisionId,
                    exchange.Context.ExecutionOverview,
                    exchange.Context.BudgetReview,
                    exchange.Decision,
                    exchange.EffectiveDecision,
                }).ToArray()));
            WriteText(runDir, "consult-bridge.json", TryJson(new
            {
                schemaVersion = "uniclaw.settings-coverage-consult-bridge.v1",
                mode = options.UseCoverageDirector ? "coverage-director" : "advisory-direct",
                exchanges = consultBridge,
            }));

            var consultSummaries = director.ConsultLog.Select(c => new
            {
                c.DecisionId,
                c.Phase,
                c.Directive,
                c.DirectiveKind,
                c.DecisionKind,
                c.DeviationReason,
                c.Attempts,
                c.Justification,
                c.PolicyDigest,
                c.GuardVerdict,
            }).ToArray();
            var facts = new
            {
                schemaVersion = "uniclaw.settings-coverage-facts.v2",
                runDir,
                status = drive.Status.ToString(),
                reason = drive.Reason,
                outcome = drive.Outcome?.Classification.ToString(),
                delivered = drive.DeliveredEffects,
                budgetRenewals = driver.RenewalsGranted,
                receipts = receipts.Select(r => r.Outcome.ToString()).ToArray(),
                terminal = kernel.IsRunTerminal,
                coverageStatus = report.Status,
                coverageRate = report.CoverageRate,
                stepSuccessRate = report.StepSuccessRate,
                uncovered = report.UncoveredItems,
                firstDivergence = report.FirstDivergence,
                terminalJustification = director.TerminalJustification,
                diagnostics = new
                {
                    firstDivergence = report.FirstDivergence,
                    terminalJustification = director.TerminalJustification,
                    nextFiles = new[] { "facts.json", "consult-bridge.json", "environment-preflight.json", "coverage-report.json", "coverage-steps.json", "trace.json", "settings-trace.json", "exec.journal", "failure.json" },
                    guidance = report.FirstDivergence is null && drive.Status == RunDriveStatus.Completed
                        ? "运行完成；如需核对每一步，先看 coverage-steps.json，再用 DecisionId 对照 trace.json。"
                        : "先看 firstDivergence/reason，再用 DecisionId 对照 coverage-steps.json、trace.json 和 exec.journal。"
                },
                languageInspection = new
                {
                    requested = languageInspection is not null,
                    file = languageInspection is null ? null : "language-findings.json",
                    findings = languageInspection?.Findings.Count ?? 0,
                    persistenceHealthy = languageInspection?.PersistenceHealthy ?? true,
                    diagnostics = languageInspection?.PersistenceDiagnostics ?? Array.Empty<string>(),
                },
                consultMode = options.UseCoverageDirector ? "coverage-director" : "advisory-direct",
                actionPolicy = config.ActionPolicy is { } policy
                    ? new { policy.PolicyRef, policy.Digest, policy.SourcePath }
                    : null,
                evidenceDir = evidenceDir,
                evidenceFiles = evidenceDir is not null && Directory.Exists(evidenceDir)
                    ? Directory.GetFiles(evidenceDir).Length
                    : 0,
                journalBytes = new FileInfo(journalPath).Length,
                consults = consultSummaries,
                steps = driver.CompletedSteps
                    .Select(s => new { decision = s.DecisionN, step = s.StepIndex, receipt = s.ReceiptId })
                    .ToArray(),
            };
            var factsJson = JsonSerializer.Serialize(facts, JsonOptions);
            WriteText(runDir, "facts.json", factsJson);
            var digest = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(
                $"{facts.status}|{facts.coverageStatus}|{facts.delivered}|{string.Join(",", facts.receipts)}|{facts.journalBytes}")));

            return new RunResult(
                runDir, drive.Status, drive.Reason, facts.outcome, report, steps,
                director.ConsultLog,
                Array.Empty<string>(),
                digest);
        }
        catch (Exception error)
        {
            try
            {
                WriteText(runDir, "consult-bridge.json", TryJson(new
                {
                    schemaVersion = "uniclaw.settings-coverage-consult-bridge.v1",
                    mode = options.UseCoverageDirector ? "coverage-director" : "advisory-direct",
                    exchanges = consultBridge,
                }));
                WriteText(runDir, "failure.json", JsonSerializer.Serialize(new
                {
                    schemaVersion = "uniclaw.settings-coverage-failure.v1",
                    runDir,
                    errorType = error.GetType().FullName,
                    message = error.Message,
                    guidance = "先看 message；再检查 environment-preflight.json、exec.journal、trace.json、settings-trace.json 和 coverage-report.json（若存在）。"
                }, JsonOptions));
            }
            catch
            {
                // Preserve the original failure if diagnostics cannot be written.
            }
            throw;
        }
        finally
        {
            liveFeed?.Dispose();
        }
    }

    /// <summary>
    /// 交错记账器：包装 feed.Next。每次观察拉取点把 (a) 上一周期 route+可见
    /// occurrences 记入账本、(b) 自上次拉取以来的新 receipts 与前后 route
    /// 配对后经 CoverageStepJournal 等待 Drain（咨询开始时携带 verification
    /// 与 DecisionId/Directive 归属写入账本）。
    /// </summary>
    private sealed class InterleaveBookkeeper
    {
        private readonly UniKernel _kernel;
        private readonly Func<ObservationDirective, RunDriverInput?> _feedNext;
        private readonly Func<string?> _currentCaptureId;
        private readonly SettingsCoverageLedger _ledger;
        private readonly CoverageStepJournal _journal;
        private readonly SettingsCoverageConfig _config;
        private readonly Action _tryBindLanguageInspection;
        private readonly Func<LanguageInspectionPostCommit?> _languageInspection;
        private readonly Action _flushVerifiedSteps;
        private string? _lastCycleRoute;
        private int _syncedReceipts;
        private bool _observedOnce;
        private bool _cycleRecorded;
        private IReadOnlyList<ObservationProposal>? _pendingInspectionProposals;
        private string? _pendingInspectionCaptureId;
        private (int Entered, int Frontier)? _lastProgress;
        private int _stagnantCycles;
        private bool _interruptionIssued;
        private int _lastInterruptionStagnant;

        public InterleaveBookkeeper(
            UniKernel kernel,
            Func<ObservationDirective, RunDriverInput?> feedNext,
            Func<string?> currentCaptureId,
            SettingsCoverageLedger ledger,
            CoverageStepJournal journal,
            SettingsCoverageConfig config,
            Action tryBindLanguageInspection,
            Func<LanguageInspectionPostCommit?> languageInspection,
            Action flushVerifiedSteps)
        {
            _kernel = kernel;
            _feedNext = feedNext;
            _currentCaptureId = currentCaptureId;
            _ledger = ledger;
            _journal = journal;
            _config = config;
            _tryBindLanguageInspection = tryBindLanguageInspection;
            _languageInspection = languageInspection;
            _flushVerifiedSteps = flushVerifiedSteps;
        }

        public RunDriverInput? WrappedNext(ObservationDirective directive)
        {
            // Plan Observe can follow verification without another Agent/guard
            // callback. Reconcile that completed receipt before judging progress;
            // never drain the receipt while its post-action verification awaits.
            if (directive.Context == ObservationContext.External)
                _flushVerifiedSteps();
            InspectPendingAfterCommit();
            // (a) 上一周期已处理完毕：其 route + 当前 belief 的可见 occurrences
            // 入账本（occurrences 为该屏 grounded 景观）。
            RecordPendingObservation();

            if (TryBuildInterruption() is { } interruption)
                return interruption;

            var input = _feedNext(directive);

            // (b) 本周期输入的 route（该屏指纹）；期间新 receipts 与
            // (前 route=上一周期, 后 route=本周期) 配对入 journal。
            var routeNow = RouteOf(input);
            var captureNow = _currentCaptureId();
            // AGT-009：本周期弹窗声明入账本（director 快照分支依据）。
            var popupNow = PopupStateOf(input);
            if (popupNow is not null)
                _ledger.RecordPopupState(popupNow);
            var receipts = _kernel.EffectReceipts;
            for (var i = _syncedReceipts; i < receipts.Count; i++)
                _journal.Enqueue(receipts[i], _lastCycleRoute, routeNow, captureNow);
            _syncedReceipts = receipts.Count;
            _lastCycleRoute = routeNow;
            _observedOnce = true;
            _cycleRecorded = false;
            if (input is RunDriverInput.Observation observation)
            {
                _pendingInspectionProposals = observation.Proposals;
                _pendingInspectionCaptureId = captureNow;
            }
            return input;
        }

        private RunDriverInput.Interruption? TryBuildInterruption()
        {
            var snapshot = _ledger.Snapshot(_config);
            // A completed scoped goal at its required root is awaiting the
            // Agent's terminal judgment, not evidence of a stalled traversal.
            if (snapshot.CoverageComplete
                && string.Equals(snapshot.CurrentRoute, _config.RootRoute, StringComparison.Ordinal))
                return null;
            var frontier = _ledger.DynamicRootFrontier(_config).Count
                + _ledger.DynamicNestedFrontier(_config).Count;
            // TRAJECTORY-001 验收修复（D3 裁决落法）：进度指纹 = (已进入/到达
            // 目标数, frontier)——**不含 StepsVerified**（RUN-006 F8 实证：
            // 弹窗循环里每个清障 tap 都"验证成功"，StepsVerified 恒涨，用它
            // 判停滞永远不触发）；也**不要求证据指纹逐轮相等**（弹窗循环的
            // 指纹是 present/absent 交替，相等条件会每轮清零计数器——
            // 验收轮实证复发根因）。停滞 = 覆盖事实无变化，与画面交替正交。
            // D3 补充执法口径：单步粒度上"清障验证不算 Coverage Progress"
            // 由 SettingsCoverageLedger.CountsAsCoverageProgress 裁定。
            // 复用Owner已验证的真实根页进入，再并入显式到达/overlay标记；
            // 同页清障不成为新进入，重复进入也不增加此去重计数。
            var entered = _ledger.EnteredRootDescriptors(_config)
                .Except(_ledger.AgentSkippedTargets, StringComparer.Ordinal)
                .Union(_ledger.TargetMarks.Values
                    .Where(mark => mark.Kind is TargetCoverageMarkKind.RouteEntered
                        or TargetCoverageMarkKind.ReachedOverlay)
                    .Select(mark => mark.Target), StringComparer.Ordinal)
                .Count();
            var progress = (entered, frontier);
            if (ShouldIncrementStagnation(_lastProgress, progress))
                _stagnantCycles++;
            else
            {
                _stagnantCycles = 0;
                _interruptionIssued = false;
            }
            _lastProgress = progress;

            // TRAJECTORY-001 冷却（真机实证修正）：Agent 答非介入选项后
            // N 轮冷却再重问（而非永久锁存——锁存致 95% 停滞周期里 Agent
            // 再无被问机会，循环无法打破）。冷却 = StagnationInjectConsults
            // 同值（数据后标定）。
            var cooldownOver = _stagnantCycles - _lastInterruptionStagnant
                >= _config.Bounds.StagnationInjectConsults;
            if (_interruptionIssued && !cooldownOver)
                return null;
            if (_stagnantCycles < _config.Bounds.StagnationInjectConsults)
                return null;

            var cutoff = _ledger.LastEventSequence;
            var events = _ledger.ReadEvents(Math.Max(0, cutoff - 11), 12);
            var heartbeatEvents = events
                .Select(ToHeartbeatEvent)
                .ToArray();
            var references = events
                .Select(ToReference)
                .ToArray();
            var heartbeat = new Heartbeat(
                new HeartbeatWorldModel(
                    CurrentRevision: null,
                    CurrentContainer: snapshot.CurrentRoute,
                    CurrentRoute: snapshot.CurrentRoute,
                    BasePageAnchor: null,
                    Overlay: snapshot.PopupState == "present" ? "popup" : null,
                    LastAcceptedObservationEventSeq: events
                        .Where(item => item.Type == CoverageEventType.ObservationAccepted)
                        .Select(item => (long?)item.Sequence)
                        .LastOrDefault(),
                    LastAcceptedObservationCaptureId: events
                        .Where(item => item.Type == CoverageEventType.ObservationAccepted)
                        .Select(item => item.CaptureId)
                        .LastOrDefault()),
                new HeartbeatKernel(
                    AgentDecisionPhase.StepVerified,
                    LastEffect: events.LastOrDefault(item => item.Type == CoverageEventType.EffectReceiptProduced)?.Target,
                    LastReceipt: events.LastOrDefault(item => item.Type == CoverageEventType.EffectReceiptProduced)?.ReceiptId,
                    LastVerification: events.LastOrDefault(item => item.Type == CoverageEventType.PostActionVerified)?.Reason,
                    PendingObligations: Array.Empty<AgentObligationView>(),
                    NextEffectBlocked: true),
                new HeartbeatTraversal(
                    CurrentTarget: snapshot.NextDirective,
                    Frontier: snapshot.Visible,
                    ReachedCount: _ledger.TargetMarks.Values.Count(mark =>
                        mark.Kind is TargetCoverageMarkKind.RouteEntered or TargetCoverageMarkKind.ReachedOverlay),
                    SkippedCount: _ledger.AgentSkippedTargets.Count,
                    PendingCount: frontier,
                    RecentTransitions: events
                        .Where(item => item.Route is not null)
                        .Select(item => item.Route!)
                        .Distinct(StringComparer.Ordinal)
                        .ToArray(),
                    RecentAttempts: events
                        .Where(item => item.Target is not null)
                        .Select(item => item.Target!)
                        .ToArray()),
                FromEventSeq: events.FirstOrDefault()?.Sequence ?? cutoff,
                ToEventSeq: cutoff,
                EventDelta: heartbeatEvents,
                OmittedCount: Math.Max(0, _ledger.Events.Count - events.Count));
            var casePacket = new CasePacket(
                CaseKind: "coverage-stagnant",
                TriggerSignals: new[] { "CoverageStagnantSignal" },
                HeartbeatSnapshot: heartbeat,
                EventDelta: heartbeatEvents,
                RelevantRefs: references,
                AvailableActions: new[] { "Reobserve", "Replan", "Blocked", "Skip" },
                Constraints: new[]
                {
                    "zero Effect for Skip and Blocked",
                    "all Act proposals remain subject to existing Grounding and Effect Boundary",
                });

            _interruptionIssued = true;
            _lastInterruptionStagnant = _stagnantCycles;
            // TRAJECTORY-001 思路引导（owner："引导 Agent 多思路，引入正确
            // 思考流程"）：Reason = 数据前置 + 推理路径 + 行为转折指令。
            var recentTargets = string.Join(", ",
                _ledger.Events
                    .Where(e => e.Type == CoverageEventType.EffectReceiptProduced && e.Target is not null)
                    .Select(e => e.Target!)
                    .Reverse().Take(8).Reverse());
            var reason = $"STAGNATION INTERVENTION (read carefully before deciding).\n"
                + $"You have been repeating the same actions without progress for {_stagnantCycles} cycles.\n"
                + $"Recent actions: [{recentTargets}]\n"
                + $"Think about this: if tapping the same target repeatedly has not completed "
                + $"the goal, doing it again will likely fail the same way.\n"
                + $"Your options NOW (pick one):\n"
                + $"  1. SKIP the current target (recommended) — submit a skip decision with the "
                + $"target name and reason; the run continues with other targets.\n"
                + $"  2. BLOCKED — submit a blocked decision with reason; the run ends honestly.\n"
                + $"  3. REOBSERVE — submit a defer; but on the NEXT consultation you MUST "
                + $"choose skip or blocked if nothing has changed.\n"
                + $"DO NOT propose the same action that has been failing. Change your approach.";
            return new RunDriverInput.Interruption(new InterruptionSignal(
                SignalKey: $"coverage-stagnant:{snapshot.NextDirective ?? "unknown"}",
                Kind: "CoverageStagnantSignal",
                EventSeq: cutoff,
                Target: snapshot.NextDirective,
                Reason: reason,
                Heartbeat: heartbeat,
                ContextReferenceIndex: references,
                CasePacket: casePacket));
        }

        private static HeartbeatEvent ToHeartbeatEvent(CoverageEvent item) =>
            new(item.Sequence, item.Type.ToString(), SemanticLabel(item), item.Target);

        private static ContextReferenceEntry ToReference(CoverageEvent item) =>
            new(
                RefId: $"coverage-event:{item.Sequence}",
                Kind: "event",
                Owner: item.Owner,
                EventSeq: item.Sequence,
                CaptureId: item.CaptureId,
                Freshness: "current",
                Lineage: $"coverage-ledger:{item.Sequence}",
                SemanticLabel: SemanticLabel(item),
                SourceAuthority: item.Owner,
                Epistemic: "observed",
                Audience: "agent",
                Redaction: "settings-coverage-default",
                Capability: "runtime.settings-coverage.events",
                MaxBytes: 8192,
                Availability: "available");

        private static string SemanticLabel(CoverageEvent item) => item.Type switch
        {
            CoverageEventType.ObservationAccepted => "accepted settings observation",
            CoverageEventType.PopupStateObserved => $"popup state observed: {item.Reason ?? "unknown"}",
            CoverageEventType.EffectReceiptProduced => $"effect receipt produced for {item.Target ?? "unknown target"}",
            CoverageEventType.PostActionVerified => $"post-action verification: {item.Verified}",
            CoverageEventType.TargetCoverageMarked => $"coverage marked: {item.MarkKind}",
            _ => "settings coverage event",
        };

        /// <summary>幂等补记当前周期（director 在快照前调用——首个观察的
        /// 处理完成先于首次咨询，但普通记账点在下一次拉取时才到）。</summary>
        public void SyncNow() => RecordPendingObservation();

        public void FlushObservation()
        {
            RecordPendingObservation();
            InspectPendingAfterCommit();
            var receipts = _kernel.EffectReceipts;
            for (var i = _syncedReceipts; i < receipts.Count; i++)
                _journal.Enqueue(receipts[i], _lastCycleRoute, null, null);
            _syncedReceipts = receipts.Count;
        }

        private void InspectPendingAfterCommit()
        {
            _tryBindLanguageInspection();
            var inspection = _languageInspection();
            if (inspection is null || _pendingInspectionProposals is null)
                return;
            inspection.InspectAfterCommit(
                _pendingInspectionProposals, _pendingInspectionCaptureId);
            _pendingInspectionProposals = null;
            _pendingInspectionCaptureId = null;
        }

        private void RecordPendingObservation()
        {
            if (!_observedOnce || _lastCycleRoute is null || _cycleRecorded)
                return;
            _ledger.RecordObservation(
                _lastCycleRoute,
                _kernel.CurrentBelief?.Occurrences?
                    .Select(o => (o.Role, o.SemanticDescriptor, o.Native?.Value)).ToArray()
                ?? Array.Empty<(string, string?, string?)>());
            _cycleRecorded = true;
        }

        private static string? RouteOf(RunDriverInput? input) =>
            input is RunDriverInput.Observation observation
                ? observation.Proposals
                    .Where(p => p.Claim.Subject == ProductAssociationStrategy.ScreenRouteSubject)
                    .Select(p => p.Claim.Value)
                    .FirstOrDefault()
                : null;

        /// <summary>AGT-009：从本周期 batch 提取弹窗声明（无声明 → null）。</summary>
        private static string? PopupStateOf(RunDriverInput? input) =>
            input is RunDriverInput.Observation observation
                ? observation.Proposals
                    .Where(p => p.Claim.Subject == ProductAssociationStrategy.PopupSubject)
                    .Select(p => p.Claim.Value)
                    .FirstOrDefault()
                : null;
    }

    /// <summary>
    /// 步骤账本缝：Enqueue（wrapper）→ Drain（咨询开始/收尾）。Drain 把
    /// 每个已配对 route 的 receipt 与 (i) 按派发序对应的 verification、
    /// (ii) 按 (role,descriptor,effect) 元组 FIFO 匹配的已采纳咨询步骤
    /// 组装成 CoverageStepRecord 写入账本（运行中实时供 director 快照）。
    /// </summary>
    public sealed class CoverageStepJournal
    {
        private readonly SettingsCoverageLedger _ledger;
        private readonly Func<IReadOnlyList<PostActionEffectVerification>> _verifications;
        private readonly Func<string?>? _sessionIdAccessor;
        private readonly List<StepArtifact> _artifacts = new();
        private readonly List<(EffectReceipt Receipt, string? RouteBefore, string? RouteAfter, string? PostCaptureId)> _pending = new();
        private readonly List<(string DecisionId, string? Directive, AgentActionStep Step)> _attributionQueue = new();
        private int _consumedVerifications;
        private int _queuedAdoptedCount;

        public CoverageStepJournal(
            SettingsCoverageLedger ledger,
            Func<IReadOnlyList<PostActionEffectVerification>> verifications,
            Func<string?>? sessionIdAccessor)
        {
            _ledger = ledger;
            _verifications = verifications;
            _sessionIdAccessor = sessionIdAccessor;
        }

        public IReadOnlyList<StepArtifact> Artifacts() => _artifacts;

        public void Enqueue(
            EffectReceipt receipt, string? routeBefore, string? routeAfter, string? postCaptureId) =>
            _pending.Add((receipt, routeBefore, routeAfter, postCaptureId));

        public void Drain(IReadOnlyList<(string DecisionId, string? Directive, AgentActionStep Step)> adoptedSteps)
        {
            // 归属队列增量同步：新采纳步骤按序入队（消费式匹配需要移除）。
            while (_queuedAdoptedCount < adoptedSteps.Count)
            {
                _attributionQueue.Add(adoptedSteps[_queuedAdoptedCount]);
                _queuedAdoptedCount++;
            }
            if (_pending.Count == 0)
                return;
            var dshSession = _sessionIdAccessor?.Invoke();
            var verifications = _verifications();
            foreach (var fact in _pending)
            {
                var verification = _consumedVerifications < verifications.Count
                    ? verifications[_consumedVerifications]
                    : null;
                if (verification is not null)
                    _consumedVerifications++;
                var attribution = Attribute(fact.Receipt, verification);
                var checks = (verification?.Checks ?? Array.Empty<AssuranceCheck>())
                    .Select(c => new KeyValuePair<string, bool>(c.Name, c.Passed))
                    .ToArray();
                var artifact = new StepArtifact(
                    Index: _artifacts.Count,
                    DecisionId: attribution?.DecisionId ?? $"unattributed-{_artifacts.Count}",
                    DshSessionId: dshSession,
                    Directive: attribution?.Directive,
                    TargetRole: attribution?.Step.TargetRole
                        ?? verification?.Target.Role ?? "",
                    TargetDescriptor: attribution?.Step.TargetDescriptor
                        ?? verification?.Target.SemanticDescriptor,
                    EffectClass: attribution?.Step.EffectClass
                        ?? verification?.Target.EffectClass ?? "",
                    DesiredState: attribution?.Step.DesiredState
                        ?? verification?.Target.DesiredState?.ToString(),
                    PreActionTargetUnique: verification != null && verification.Checks.Any(
                        c => c.Name == "post-action-target-unique" && c.Passed),
                    ReceiptId: fact.Receipt.ReceiptId,
                    ReceiptOutcome: fact.Receipt.Outcome.ToString(),
                    ReceiptCommand: fact.Receipt.Report,
                    RouteBefore: fact.RouteBefore,
                    RouteAfter: fact.RouteAfter,
                    PostCaptureId: fact.PostCaptureId,
                    Verified: verification?.IsVerified == true,
                    FailureReason: verification?.RejectionReason ?? fact.Receipt.Reason,
                    Checks: checks);
                _artifacts.Add(artifact);
                _ledger.RecordStep(new CoverageStepRecord(
                    artifact.Index, artifact.DecisionId, artifact.DshSessionId,
                    artifact.TargetRole, artifact.TargetDescriptor, artifact.EffectClass,
                    artifact.DesiredState,
                    artifact.PreActionTargetUnique, artifact.ReceiptId, artifact.ReceiptOutcome,
                    artifact.ReceiptCommand,
                    artifact.RouteBefore, artifact.RouteAfter, artifact.PostCaptureId,
                    artifact.Verified, artifact.FailureReason, artifact.Directive));
            }
            _pending.Clear();
        }

        /// <summary>元组匹配：verification.Target 与归属队列按
        /// (role, descriptor, effectClass) 相等消费（匹配即移除——重复进入
        /// 同目标的第二次步骤归属到第二次咨询）；无 verification 的
        /// （Unconfirmed 提前终止）按队首归属。</summary>
        private (string DecisionId, string? Directive, AgentActionStep Step)? Attribute(
            EffectReceipt receipt,
            PostActionEffectVerification? verification)
        {
            if (verification is not null)
            {
                var index = _attributionQueue.FindIndex(candidate =>
                    candidate.Step.TargetRole == verification.Target.Role
                    && candidate.Step.TargetDescriptor == verification.Target.SemanticDescriptor
                    && candidate.Step.EffectClass == verification.Target.EffectClass);
                if (index < 0)
                    return null;
                var matched = _attributionQueue[index];
                _attributionQueue.RemoveAt(index);
                return matched;
            }
            if (_attributionQueue.Count == 0)
                return null;
            var head = _attributionQueue[0];
            _attributionQueue.RemoveAt(0);
            return head;
        }
    }

    private static readonly JsonSerializerOptions JsonOptions =
        new(JsonSerializerDefaults.Web) { WriteIndented = true };

    private static string TryJson<T>(T value)
    {
        try { return JsonSerializer.Serialize(value, JsonOptions); }
        catch (Exception) { return value?.ToString() ?? "<null>"; }
    }

    private static void WriteText(string dir, string name, string content) =>
        File.WriteAllText(Path.Combine(dir, name), content);

    private static ConsultDecisionArtifact? ToConsultArtifact(AgentDecision? decision) =>
        decision switch
        {
            null => null,
            AgentDecision.Act act => new ConsultDecisionArtifact(
                "act", act.Proposal.Justification, act.Proposal.Steps, Renewal: act.Proposal.Renewal,
                ReviewResponse: act.ReviewResponse),
            AgentDecision.Plan plan => new ConsultDecisionArtifact(
                "plan", plan.Proposal.Justification, plan.Proposal.Items
                    .OfType<PlanItem.ActItem>()
                    .Select(item => new AgentActionStep(item.TargetRole, item.TargetDescriptor,
                        item.EffectClass, item.DesiredState))
                    .ToArray(), ReviewResponse: plan.ReviewResponse),
            AgentDecision.NoAction noAction => new ConsultDecisionArtifact(
                "noAction", noAction.Proposal.Justification, Array.Empty<AgentActionStep>(), Renewal: noAction.Proposal.Renewal,
                ReviewResponse: noAction.ReviewResponse),
            AgentDecision.Defer defer => new ConsultDecisionArtifact(
                "defer", null, Array.Empty<AgentActionStep>(), Renewal: defer.Renewal,
                ReviewResponse: defer.ReviewResponse),
            AgentDecision.Policy policy => new ConsultDecisionArtifact(
                "policy", null, Array.Empty<AgentActionStep>(), ReviewResponse: policy.ReviewResponse),
            AgentDecision.Skip skip => new ConsultDecisionArtifact(
                "skip", null, Array.Empty<AgentActionStep>(),
                skip.Target, skip.Reason, skip.EvidenceRefs, ReviewResponse: skip.ReviewResponse),
            AgentDecision.Blocked blocked => new ConsultDecisionArtifact(
                "blocked", blocked.Reason, Array.Empty<AgentActionStep>(), ReviewResponse: blocked.ReviewResponse),
            _ => new ConsultDecisionArtifact("unknown", null, Array.Empty<AgentActionStep>()),
        };
}
