namespace UniClaw.Agent.Profile;

/// <summary>一个产品模型角色的装配声明（Q4/ADR-0041）：角色名必须是编译
/// <c>LogicalProfileId</c> 值域成员；<c>Required</c> 决定组合根装配时缺绑定
/// 是拒启（true）还是诚实 NotConfigured（false）。</summary>
public sealed record ModelRoleDeclaration(string Role, bool Required);

/// <summary>Stable semantic charter for the product agent. It describes role,
/// responsibilities, boundaries and planning posture; it grants no capability
/// and contains no task-specific UI procedure.</summary>
public sealed record ProfileCharter
{
    public ProfileCharter(
        string role,
        IReadOnlyList<string> responsibilities,
        IReadOnlyList<string> boundaries,
        IReadOnlyList<string> planningPrinciples,
        IReadOnlyList<string> skillUse)
    {
        ArgumentNullException.ThrowIfNull(role);
        Role = role;
        Responsibilities = Copy(responsibilities, nameof(responsibilities));
        Boundaries = Copy(boundaries, nameof(boundaries));
        PlanningPrinciples = Copy(planningPrinciples, nameof(planningPrinciples));
        SkillUse = Copy(skillUse, nameof(skillUse));
    }

    public string Role { get; }
    public IReadOnlyList<string> Responsibilities { get; }
    public IReadOnlyList<string> Boundaries { get; }
    public IReadOnlyList<string> PlanningPrinciples { get; }
    public IReadOnlyList<string> SkillUse { get; }

    private static IReadOnlyList<string> Copy(IReadOnlyList<string> source, string parameterName)
    {
        ArgumentNullException.ThrowIfNull(source, parameterName);
        return Array.AsReadOnly(source.ToArray());
    }
}

/// <summary>产品工件引用（PRF-005/ADR-0041）：路径相对仓库根，hash 是工件
/// 内容指纹；loader 在装配时 fail-closed 校验（存在 + hash 匹配）。</summary>
public sealed record AssemblyReference(string Path, string Hash);

/// <summary>Product Skill allowlist entry. The readable name is the stable
/// product vocabulary; revision and hash pin the boot artifact.</summary>
public sealed record SkillReference(string Name, int Revision, string Path, string Sha256);

/// <summary>profile 的产品工件装配引用：静态 prompt manifest 与安全 policy。
/// 每个成员可选；一旦声明即执法。</summary>
public sealed record ProfileAssembly(
    AssemblyReference? PromptManifest = null,
    AssemblyReference? SafetyPolicy = null);

/// <summary>host-neutral UniAgent Profile 的加载结果：编译身份 + 装配修订号
/// + 模型角色声明 + 工件引用。不含 provider/model 名、服务端点或任何
/// 运行态（ADR-0041）。</summary>
public sealed record UniAgentProfile(
    ProductProfile Identity,
    int Revision,
    ProfileCharter Charter,
    IReadOnlyList<ModelRoleDeclaration> ModelRoles,
    ProfileAssembly? Assembly = null,
    IReadOnlyList<SkillReference>? AllowedSkillRefs = null);
