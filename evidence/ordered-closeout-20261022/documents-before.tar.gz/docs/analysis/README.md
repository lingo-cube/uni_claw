# analysis/ 索引（考察既有现实 · Authority: NONE · 永非规范）

> 规则见 docs/README.md §1/§2/§3：分析结论要产生约束力，必须经 change
> Status: DRAFT（梳理/调研产物，未授权实现）
> Authority: `NONE`（分析产物，不是架构决策；与 ADR / baseline 冲突时以后者为准）
> 落入 design/adr/architecture，而非原地升格。

| 文档 | 用途 | 状态 |
|---|---|---|
| `harness-v2-compatibility-matrix.md` | V2 兼容性矩阵 | COMPLETE / EVIDENCE-BACKED |
| `harness-v2-phase0-inventory.md` | V2 Phase-0 盘点 | COMPLETE / EVIDENCE-BACKED |
| `harness-v2-phase1-protocol-inventory.md` | V2 协议盘点 | COMPLETE / EVIDENCE-BACKED |
| `harness-v2-semantic-migration-matrix.md` | V2 语义迁移矩阵 | COMPLETE |
| `harness-v2-skill-provenance-inventory.md` | skill 溯源盘点（真相在 skills-lock.json） | COMPLETE |
| `legacy-perception-evidence-assessment.md` | legacy 感知资产评估（PER-002 证据基础） | CANDIDATE / NOT_ADOPTED |
| `uni-agent-perception-implementation-analysis.md` | legacy 感知实现分析（PER-005 证据基础） | CANDIDATE / NOT_ADOPTED |
| `uni-agent-trace-replayability-analysis.md` | legacy Trace 可重放性分析 | CANDIDATE / NOT_ADOPTED |
| `uniclaw-product-architecture-migration-baseline-l0-l3.md` | 基线拆分导航（→ architecture/ 三资产） | SPLIT / ROUTER |
| `per-005-algorithm-library-options.md` | OPT 系列候选调研（算法/库/优化） | CANDIDATE / NOT_ADOPTED |
| `per-005-ocr-backend-research.md` | OCR/推理后端候选调研 | CANDIDATE / NOT_ADOPTED |
| `dsh-tool-scope-restricted-sessions.md` | DSH 工具可见性语义与受限会话正确实现形状 | COMPLETE / EVIDENCE-BACKED |
| `agt-002-b1-fix-instruction.md` | AGT-002 B1 工具面泄漏修复指令（据上篇起草） | CANDIDATE |
| `fast-perception-strategy-seam-fate.md` | IFastPerceptionStrategy 去留裁决材料：牵连面盘点 + 三路线成本（PER-021） | COMPLETE / EVIDENCE-BACKED |
| `sim-006-first-baseline-matrix.md` | SIM-006 首批 8 场景+组件契约双轴基线矩阵（A1 交付物） | COMPLETE / EVIDENCE-BACKED |
| `uniclaw-architecture-protocol-overall-review-2026-10-11.md` | UniClaw 产品架构、层级轴、概念、Owner/Authority、P1–P26 与外围 O1–O12 协议审阅底稿 | REVIEW_IN_PROGRESS / ARCHITECTURE_AND_PROTOCOL_DIRECTION_ACCEPTED |
| `uniclaw-module-boundary-design-review-2026-10-21.md` | 模块职责与边界审查：逐组件检查、3 个 P1 与 4 个 P2、隔离复验证据 | COMPLETE / READ_ONLY_REVIEW |
| `uniclaw-directory-organization-review-2026-10-21.md` | 组件目录组织审查：导航、物理归属、产物分离、索引和候选整理顺序 | COMPLETE / READ_ONLY_REVIEW |
