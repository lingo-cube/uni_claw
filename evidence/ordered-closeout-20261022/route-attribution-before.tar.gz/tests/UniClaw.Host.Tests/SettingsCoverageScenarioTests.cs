using System.Text;
using System.Text.Json;
using UniClaw.Host;
using UniClaw.Host.Capability;
using UniClaw.Host.SettingsCoverage;
using UniClaw.Kernel.Capability;
using UniClaw.Kernel.Effects;
using UniClaw.Kernel.Evidence;
using UniClaw.Kernel.Perception;
using UniClaw.Kernel.Perception.UiHierarchy;
using UniClaw.Kernel.Runtime;
using Xunit;

namespace UniClaw.Host.Tests;

/// <summary>
/// AGT-005 — 确定性场景认证：模拟 Settings 世界（反应式 feed + dry-run
/// driver）贯穿 SettingsCoverageRunner 全链。证明：配置驱动的覆盖任务
/// （根页/全可见一级入口/滚动发现/二级页/返回/重复进入）在一次 Kernel run
/// 内完成；每步有 DecisionId/回执/路由前后/验证 checks 的完整 trace；
/// 偏离模型经有界纠正恢复；持续偏离 fail closed。
/// </summary>
public sealed class SettingsCoverageScenarioTests
{
    private const int Width = 1080;
    private const int Height = 1920;
    // AGT-010 §2：RootRoute 迁移为多信号 RouteKey（标题×来源×up×滚动容器）
    private const string RootRoute =
        "android.settings|rk1:Settings|src=homepage_title|up=0";
    private static readonly string[] VisiblePages =
    {
        "Network & internet", "Connected devices", "Apps", "Notifications",
        "Battery", "Storage", "Sound & vibration",
        // AGT-010 §2 撞名实证复刻：二级页标题同为 "Settings"（Security & privacy）
        "Security & privacy",
    };
    private static readonly string[] ScrolledPages =
    {
        "Battery", "Storage", "Sound & vibration", "Security & privacy", "Accessibility", "System",
    };
    private const string ScrollContainer = "com.android.settings:id/main_content_scrollable_container";
    /// <summary>AGT-010：撞名二级页——标题渲染为 "Settings"（与根页同标题），
    /// 身份只能靠 src/up/sc 多信号区分。</summary>
    private const string CollidingPage = "Security & privacy";

    /// <summary>
    /// 反应式模拟世界：维护 route/scroll 状态；feed 按状态出 XML 观察；
    /// driver 按坐标命中映射为 tap/swipe 世界迁移。
    /// </summary>
    private sealed class SimulatedSettingsWorld
    {
        public bool EnableNestedPlanFixture { get; init; }
        private readonly Stack<string> _returnRoutes = new();
        private int _captureCounter;
        private int _scrollOffset;
        private int _transitionalCycles;
        private bool _popupArmed;
        private bool _popupActive;
        private bool _atBottom;

        public string Route { get; private set; } = RootRoute;

        /// <summary>AGT-006：前 N 个周期返回无标题过渡屏（路由回退身份）。</summary>
        public void StartTransitional(int cycles)
        {
            _transitionalCycles = cycles;
            Route = "android.settings";
        }

        /// <summary>AGT-009：下一次进入二级页时弹 permissioncontroller 弹窗。</summary>
        public void ArmPopupOnNextSecondLevelEntry() => _popupArmed = true;

        /// <summary>AGT-009：弹窗是否在场（清障后应 false）。</summary>
        public bool PopupActive => _popupActive;

        public (string Descriptor, int X1, int Y1, int X2, int Y2)[] HitRegions =>
            (_popupActive
                ? new[]
                {
                    // 词汇优先序：CANCEL（button2）在 DISMISS（button1）之前
                    ("CANCEL", 540, 900, 900, 1000),
                    ("DISMISS", 180, 900, 540, 1000),
                }
                : Array.Empty<(string, int, int, int, int)>())
            .Concat(CurrentEntries
                .Select((descriptor, index) => (descriptor, 0, 260 + index * 150, Width, 260 + index * 150 + 140)))
            .Concat(new[] { ("Navigate up", 0, 40, 150, 190) })
            .ToArray()!;

        private string[] CurrentEntries => EnableNestedPlanFixture && Route != RootRoute
            ? Route == "android.settings|route:Network & internet" ? new[] { "Connection details" } : Array.Empty<string>()
            : _scrollOffset == 0 ? VisiblePages : ScrolledPages;

        public string TapAt(int x, int y)
        {
            var region = HitRegions.FirstOrDefault(r => x >= r.X1 && x < r.X2 && y >= r.Y1 && y < r.Y2);
            if (region.Descriptor is null or "")
                return "miss";
            if (region.Descriptor is "CANCEL" or "DISMISS")
            {
                _popupActive = false;
                return region.Descriptor;
            }
            if (region.Descriptor == "Navigate up")
            {
                if (Route != RootRoute)
                    Route = EnableNestedPlanFixture && _returnRoutes.Count > 0 ? _returnRoutes.Pop() : RootRoute;
                return "Navigate up";
            }
            if (Route == RootRoute || EnableNestedPlanFixture)
            {
                if (EnableNestedPlanFixture) _returnRoutes.Push(Route);
                Route = $"android.settings|route:{region.Descriptor}";
                if (_popupArmed)
                {
                    // AGT-009：随进入二级页弹窗出现（permissioncontroller 覆盖层）
                    _popupArmed = false;
                    _popupActive = true;
                }
            }
            return region.Descriptor;
        }

        /// <summary>AGT-010 §3：列表已在底部（swipe 永不改变内容）。</summary>
        public void MakeAlreadyAtBottom() => _atBottom = true;

        public bool ScrollUp() => Route == RootRoute && !_atBottom && _scrollOffset++ == 0;

        public string BuildXml()
        {
            var builder = new StringBuilder();
            builder.Append("""<?xml version='1.0' encoding='UTF-8'?><hierarchy rotation="0">""");
            if (_popupActive)
            {
                // AGT-009 §1：弹窗结构事实——窗口根 package ≠ hostPackage
                //（permissioncontroller）∨ 命中 alertTitle/parentPanel/buttonPanel
                // 白名单；首个 node 即窗口根。几何不作判据。
                builder.Append(Node("android:id/parentPanel", "android.widget.LinearLayout",
                    text: null, clickable: false, bounds: "[120,700][960,1120]",
                    package: "com.android.permissioncontroller"));
                builder.Append(Node("android:id/alertTitle", "android.widget.TextView",
                    text: "Allow Settings to modify system settings?", clickable: false,
                    bounds: "[160,740][920,820]", package: "com.android.permissioncontroller"));
                builder.Append(Node("android:id/button2", "android.widget.Button",
                    text: "CANCEL", clickable: true, bounds: "[540,900][900,1000]",
                    package: "com.android.permissioncontroller"));
                builder.Append(Node("android:id/button1", "android.widget.Button",
                    text: "DISMISS", clickable: true, bounds: "[180,900][540,1000]",
                    package: "com.android.permissioncontroller"));
            }
            if (Route == RootRoute)
            {
                builder.Append(Node(ScrollContainer, "android.widget.ScrollView", text: null,
                    scrollable: true, clickable: false, bounds: "[0,200][1080,1800]"));
                builder.Append(Node("com.android.settings:id/homepage_title", "android.widget.TextView",
                    text: "Settings", clickable: false, bounds: "[40,80][1040,180]"));
                for (var i = 0; i < CurrentEntries.Length; i++)
                    builder.Append(Node("", "android.widget.LinearLayout", text: CurrentEntries[i],
                        clickable: true, bounds: $"[0,{260 + i * 150}][{Width},{260 + i * 150 + 140}]"));
            }
            else if (Route == "android.settings")
            {
                // 过渡屏：无标题（路由回退身份）、无可 grounding 的返回键。
                builder.Append(Node(ScrollContainer, "android.widget.ScrollView", text: null,
                    scrollable: true, clickable: false, bounds: "[0,200][1080,1800]"));
            }
            else
            {
                // AGT-010：撞名页标题渲染为 "Settings"（实录 Security & privacy
                // 行为复刻）；页面身份由 src/up/sc 多信号与根页区分。
                var title = Route == $"android.settings|route:{CollidingPage}"
                    ? "Settings"
                    : Route["android.settings|route:".Length..];
                builder.Append(Node("android:id/up", "android.widget.ImageButton", text: null,
                    contentDesc: "Navigate up", clickable: true, bounds: "[0,40][150,190]"));
                builder.Append(Node("android:id/title", "android.widget.TextView", text: title,
                    clickable: false, bounds: "[200,80][1040,180]"));
                builder.Append(Node("com.android.settings:id/content_parent", "android.widget.ScrollView",
                    text: null, scrollable: true, clickable: false, bounds: "[0,250][1080,1800]"));
                if (EnableNestedPlanFixture)
                {
                    for (var i = 0; i < CurrentEntries.Length; i++)
                        builder.Append(Node("", "android.widget.LinearLayout", text: CurrentEntries[i],
                            clickable: true, bounds: $"[0,{260 + i * 150}][{Width},{260 + i * 150 + 140}]"));
                    builder.Append(Node("com.android.settings:id/record_only_switch", "android.widget.Switch",
                        text: "Record only setting", clickable: true, bounds: "[0,600][1080,740]")
                        .Replace("checkable=\"false\"", "checkable=\"true\"", StringComparison.Ordinal));
                }
                else
                    builder.Append(Node("", "android.widget.LinearLayout", text: $"{title} content",
                        clickable: true, bounds: "[0,300][1080,440]"));
            }
            builder.Append("</hierarchy>");
            return builder.ToString();
        }

        public RunDriverInput? Next(ObservationDirective directive)
        {
            var captureId = $"sim-capture-{++_captureCounter:D4}";
            var xml = BuildXml();
            var route = SettingsTraversalLiveFeed.DeriveRouteKey(xml);
            // 过渡推进在本周期 XML 之后：当前周期如实呈现过渡屏，下一周期定形。
            if (_transitionalCycles > 0)
            {
                _transitionalCycles--;
                if (_transitionalCycles == 0)
                    Route = RootRoute;
            }
            var proposals = new List<ObservationProposal>
            {
                new(
                    new ObservationClaim(
                        UniClaw.Kernel.World.UiRealization.ProductAssociationStrategy.ScreenIdentitySubject,
                        "android.settings"),
                    IngressKind.Observation,
                    directive.Context,
                    new Provenance(
                        "host.sim.settings", DateTimeOffset.UtcNow, "scope:ui.screen",
                        new[] { "simulated-device", "capture:" + captureId })),
                new(
                    new ObservationClaim(
                        UniClaw.Kernel.World.UiRealization.ProductAssociationStrategy.ScreenRouteSubject,
                        route),
                    IngressKind.Observation,
                    directive.Context,
                    new Provenance(
                        "host.sim.settings", DateTimeOffset.UtcNow,
                        $"scope:ui.screen.route:sim-{_captureCounter:D4}",
                        new[] { "simulated-device", "capture:" + captureId, "route-fingerprint" })),
            };
            var parsed = UiAutomatorDump.ParseHierarchyObservation(
                xml,
                new UiAutomatorDump.UiHierarchyParseContext(
                    captureId, DateTimeOffset.UtcNow, "emulator-sim", "settings:sim", 35,
                    ObservationCycleId: $"sim-cycle-{_captureCounter:D4}",
                    Space: CoordinateSpace.DeviceViewport(Width, Height)));
            if (parsed.Observation is { } observation)
                proposals.AddRange(TypedHierarchyProposalProjector.Project(observation, directive.Context));
            // AGT-009：同分类器 typed 弹窗声明入证据流（ui.overlay.popup；
            // 无 XML/不可解析 → 无声明）。与真实 feed 同形。
            if (SettingsTraversalLiveFeed.PopupProposal(
                    SettingsTraversalLiveFeed.DerivePopupState(xml, "com.android.settings"),
                    captureId, $"sim-cycle-{_captureCounter:D4}", DateTimeOffset.UtcNow,
                    directive.Context)
                is { } popupProposal)
                proposals.Add(popupProposal);
            return new RunDriverInput.Observation(proposals);
        }

        public string CurrentCaptureId => $"sim-capture-{_captureCounter:D4}";

        private static string Node(
            string resourceId, string @class, string? text, bool clickable, string bounds,
            string? contentDesc = null, bool scrollable = false,
            string? package = null) =>
            $"""<node index="0" text="{Escape(text)}" resource-id="{Escape(resourceId)}" class="{Escape(@class)}" """
            + $"""package="{Escape(package ?? "com.android.settings")}" content-desc="{Escape(contentDesc)}" checkable="false" """
            + $"""checked="false" clickable="{(clickable ? "true" : "false")}" enabled="true" """
            + $"""focusable="true" focused="false" scrollable="{(scrollable ? "true" : "false")}" """
            + $"""long-clickable="false" password="false" selected="false" bounds="{Escape(bounds)}"/>""";

        private static string? Escape(string? value) =>
            value is null ? null
            : value.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
    }

    private sealed class SimulatedEffectDriver(SimulatedSettingsWorld world) : IEffectDriver
    {
        public DispatchResult Deliver(DispatchRequest request)
        {
            ArgumentNullException.ThrowIfNull(request);
            var locator = request.Target.Spatial
                ?? throw new InvalidOperationException("sim driver requires spatial target");
            var effect = request.EffectClass.ToLowerInvariant();
            if (effect is "swipe-up" or "swipe-down")
            {
                var changed = world.ScrollUp();
                return new DispatchResult(
                    DispatchOutcome.DeliveryCompleted,
                    $"sim {effect} (changed={changed})",
                    DateTimeOffset.UtcNow);
            }
            var x = (int)(locator.CenterX * Width);
            var y = (int)(locator.CenterY * Height);
            var hit = world.TapAt(x, y);
            return new DispatchResult(
                DispatchOutcome.DeliveryCompleted,
                $"sim tap {hit} @({x},{y})",
                DateTimeOffset.UtcNow);
        }
    }

    /// <summary>守规矩的确定性「模型」：按 directive 提案单步 Act。</summary>
    private static AgentDecision? ModelConsult(AgentDecisionContext context)
    {
        var marker = "COVERAGE DIRECTIVE (authoritative for this turn): ";
        var start = context.Objective.IndexOf(marker, StringComparison.Ordinal);
        if (start < 0)
            throw new InvalidOperationException("model double: directive missing");
        var directive = context.Objective[(start + marker.Length)..]
            .Split('\n', 2)[0].Trim();
        var target = ExtractTarget(directive);
        if (directive.StartsWith("Scroll", StringComparison.Ordinal))
            return Act(context, "scrollable", ScrollContainer, "swipe-up");
        return Act(context, "ui.element", target!, "tap");
    }

    /// <summary>
    /// AGT-009 §11 模型：obstacle directive 以受约束 advisory Plan 回答
    ///（恰一个 ActItem=词汇命中的清障 tap + ObserveItem(popup 补证)）；
    /// 其余 directive 照旧单步 Act。
    /// </summary>
    private static AgentDecision? ObstaclePlanModelConsult(AgentDecisionContext context)
    {
        var marker = "COVERAGE DIRECTIVE (authoritative for this turn): ";
        var start = context.Objective.IndexOf(marker, StringComparison.Ordinal);
        if (start < 0)
            throw new InvalidOperationException("model double: directive missing");
        var directive = context.Objective[(start + marker.Length)..]
            .Split('\n', 2)[0].Trim();
        if (directive.StartsWith("Clear the popup", StringComparison.Ordinal))
        {
            var target = ExtractTarget(directive);
            return new AgentDecision.Plan(context.DecisionId, new AgentPlanProposal(
                new PlanItem[]
                {
                    new PlanItem.ActItem("ui.element", target, "tap", null),
                    new PlanItem.ObserveItem(UniClaw.Kernel.World.UiRealization.ProductAssociationStrategy.PopupSubject),
                },
                Justification: "obstacle-clearance-plan"));
        }
        if (directive.StartsWith("Scroll", StringComparison.Ordinal))
            return Act(context, "scrollable", ScrollContainer, "swipe-up");
        return Act(context, "ui.element", ExtractTarget(directive)!, "tap");
    }

    private static readonly HashSet<string> DeviatedDecisionIds = new();

    private static AgentDecision? DeviatingModelConsult(AgentDecisionContext context)
    {
        if (!context.Objective.Contains("COVERAGE DIRECTIVE", StringComparison.Ordinal))
            return ModelConsult(context);
        // 同一 DecisionId 首次咨询偏离一次；纠正再咨询后守规矩。
        if (DeviatedDecisionIds.Add(context.DecisionId))
            return new AgentDecision.Act(new AgentActionProposal(
                context.DecisionId,
                new[] { new AgentActionStep("ui.element", "Storage", "tap", null) },
                Justification: "deviating-model"));
        return ModelConsult(context);
    }

    private static AgentDecision Act(
        AgentDecisionContext context, string role, string descriptor, string effect) =>
        new AgentDecision.Act(new AgentActionProposal(
            context.DecisionId,
            new[] { new AgentActionStep(role, descriptor, effect, null) },
            Justification: "model-double"));

    private static string? ExtractTarget(string directive)
    {
        var start = directive.IndexOf('<');
        var end = directive.IndexOf('>');
        return start >= 0 && end > start ? directive[(start + 1)..end] : null;
    }

    private static SettingsCoverageConfig ConfigWith(
        int maxSteps = 24, int maxScrolls = 4, int maxDirectiveRetries = 1) =>
        SettingsCoverageConfig.Load(WriteTempConfig(maxSteps, maxScrolls, maxDirectiveRetries));

    private static string WriteTempConfig(int maxSteps, int maxScrolls, int maxDirectiveRetries)
    {
        var path = Path.Combine(Path.GetTempPath(), $"settings-coverage-sim-{Guid.NewGuid():N}.yaml");
        File.WriteAllText(path, $"""
            configVersion: "1"
            session:
              taskTitle: 遍历设置菜单覆盖测试
              workspace: UniClaw_Product_Tasks
              workspaceReuse: true
              autoCloseTurn: false
            bounds:
              maxSteps: {maxSteps}
              maxConsultRounds: 30
              maxScrolls: {maxScrolls}
              maxConsecutiveFailures: 3
              maxDirectiveRetries: {maxDirectiveRetries}
            coverage:
              rootPage: true
              firstLevelMode: all-visible
              scrollDiscoveredEntries: 1
              secondLevelPages: 2
              backNavigation: true
              repeatedEntries: 1
            targetPages:
              - Network & internet
              - Connected devices
              - Apps
              - Notifications
              - Battery
              - Storage
              - Sound & vibration
              - Security & privacy
            termination:
              onCoverageComplete: true
              onMaxSteps: true
              onMaxScrolls: true
              onConsecutiveFailures: true
            rootRoute: {RootRoute}
            scrollContainerDescriptor: {ScrollContainer}
            backDescriptor: Navigate up
            """);
        return path;
    }

    private static SettingsCoverageRunner.RunResult RunScenario(
        Func<AgentDecisionContext, AgentDecision?> model,
        SettingsCoverageConfig? config = null)
    {
        var world = new SimulatedSettingsWorld();
        var assets = new LivePerception.LiveAssets(
            "emulator-sim", "wifi-settings", "/nonexistent", "/nonexistent/python", "/nonexistent/cache");
        var runRoot = Path.Combine(Path.GetTempPath(), $"settings-coverage-run-{Guid.NewGuid():N}");
        return SettingsCoverageRunner.Run(runRoot, new SettingsCoverageRunner.Options(
            DeviceId: "emulator-sim",
            Live: assets,
            Config: config ?? ConfigWith(),
            UnderlyingConsult: model,
            DshSessionIdAccessor: () => "session-sim-0001",
            FeedNext: world.Next,
            CurrentCaptureId: () => world.CurrentCaptureId,
            EffectDriver: new SimulatedEffectDriver(world)));
    }

    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public void ComposablePlan_CurrentStepGuardAndReceiptAttributionRunThroughSameHost(bool rule, bool observeAfterCoverage)
    {
        var original = SettingsCoverageConfig.LoadDefault();
        var config = ConfigWith() with
        {
            Bounds = original.Bounds with { MaxSteps = 16, MaxConsultRounds = 16,
                RenewalThresholdSteps = 1, RenewalThresholdRounds = 2 },
            Coverage = new CoverageRequirements(true, "all-visible", 0, 0, true, 0),
            TargetPages = new[] { "Network & internet", "Connected devices" },
            ActionPolicy = original.ActionPolicy, ActionPolicyRequired = true,
        };
        var world = new SimulatedSettingsWorld();
        var consults = 0;
        var consultFailures = new List<string?>();
        var runRoot = Path.Combine(Path.GetTempPath(), "composable-host-" + Guid.NewGuid().ToString("N"));
        var result = SettingsCoverageRunner.Run(runRoot, new SettingsCoverageRunner.Options(
            "emulator-sim", new LivePerception.LiveAssets("emulator-sim", "wifi-settings", "/nonexistent", "/nonexistent", "/nonexistent"),
            config, context =>
            {
                if (++consults > 1)
                {
                    consultFailures.Add(context.FailureReason);
                    return new AgentDecision.NoAction(new AgentNoActionProposal(context.DecisionId, "scoped target entries and returns verified"));
                }
                var items = rule ? new PlanItem[]
                {
                    new PlanItem.ForEachItem(SettingsPlanFacts.RootNavigationSource, new PlanItem[]
                    {
                        new PlanItem.ActItem("$candidate", "$candidate", "tap", null),
                        new PlanItem.ObserveItem(null),
                        new PlanItem.ActItem("ui.element", "Navigate up", "tap", null),
                    }, 2),
                } : config.TargetPages.SelectMany(target => new PlanItem[]
                {
                    new PlanItem.ActItem("ui.element", target, "tap", null),
                    new PlanItem.ObserveItem(null),
                    new PlanItem.ActItem("ui.element", "Navigate up", "tap", null),
                }).ToArray();
                if (observeAfterCoverage)
                    items = items.Concat(Enumerable.Repeat<PlanItem>(new PlanItem.ObserveItem(null), 4)).ToArray();
                return new AgentDecision.Plan(context.DecisionId, new AgentPlanProposal(items, "scoped host plan", "host-plan", 1, "two root entries", 30));
            }, ViewportWidth: Width, ViewportHeight: Height, FeedNext: world.Next,
            CurrentCaptureId: () => world.CurrentCaptureId, EffectDriver: new SimulatedEffectDriver(world), UseCoverageDirector: false));
        if (observeAfterCoverage)
            Assert.DoesNotContain(consultFailures, reason => reason?.Contains("STAGNATION INTERVENTION", StringComparison.Ordinal) == true);
        Assert.Equal(RunDriveStatus.Completed, result.Status);
        Assert.Equal("CoverageComplete", result.Report.Status);
        Assert.Equal(4, result.Steps.Count(step => step.Verified));
        Assert.Equal(2, consults);
        Assert.All(result.Steps, step => Assert.DoesNotContain("unattributed", step.DecisionId));
        Assert.Equal(4, result.Steps.Select(step => step.ReceiptId).Distinct().Count());
        using var guards = JsonDocument.Parse(File.ReadAllText(Path.Combine(result.RunDir, "current-step-guards.json")));
        Assert.Equal(4, guards.RootElement.GetArrayLength());
        Assert.True(File.Exists(Path.Combine(result.RunDir, "consultations.journal.jsonl")));
    }

    [Fact]
    public void ConditionalPlan_VisitsNewChildAndReturnsBeforeContinuingRootWithoutUiNamesInPlan()
    {
        var original = SettingsCoverageConfig.LoadDefault();
        var config = ConfigWith() with
        {
            Bounds = original.Bounds with { MaxSteps = 16, MaxConsultRounds = 16,
                RenewalThresholdSteps = 1, RenewalThresholdRounds = 2 },
            Coverage = new CoverageRequirements(true, "all-visible", 0, 0, true, 0),
            TargetPages = new[] { "Network & internet", "Connected devices" },
            DynamicRootEntries = new DynamicRootEntriesConfig(false),
            DynamicNestedEntries = new DynamicNestedEntriesConfig(true, 1, 1),
            ActionPolicy = original.ActionPolicy, ActionPolicyRequired = true,
        };
        var world = new SimulatedSettingsWorld { EnableNestedPlanFixture = true };
        var consults = 0;
        var runRoot = Path.Combine(Path.GetTempPath(), "conditional-ui-host-" + Guid.NewGuid().ToString("N"));
        var result = SettingsCoverageRunner.Run(runRoot, new SettingsCoverageRunner.Options(
            "emulator-sim", new LivePerception.LiveAssets("emulator-sim", "wifi-settings", "/nonexistent", "/nonexistent", "/nonexistent"),
            config, context =>
            {
                if (++consults > 1)
                {
                    Assert.Null(context.FailureReason);
                    return new AgentDecision.NoAction(new AgentNoActionProposal(context.DecisionId, "scoped pages and controls observed"));
                }
                Assert.Contains(SettingsPlanFacts.HasNavigationCondition, context.AvailablePlanConditions!.Keys);
                Assert.DoesNotContain("navigation", context.AvailablePlanConditions.Keys);
                Assert.DoesNotContain("readOnly", context.AvailablePlanConditions.Keys);
                var traversalSource = context.AvailablePlanSources![SettingsTraversalProjection.Source];
                Assert.Contains("navigation", traversalSource);
                Assert.Contains("readOnly", traversalSource);
                return new AgentDecision.Plan(context.DecisionId, new AgentPlanProposal(new PlanItem[]
                {
                    new PlanItem.RepeatItem(new PlanItem[]
                    {
                        new PlanItem.IfItem(SettingsPlanFacts.HasNavigationCondition,
                            new PlanItem[]
                            {
                                new PlanItem.ForEachItem(SettingsPlanFacts.CurrentNavigationSource,
                                    new PlanItem[] { new PlanItem.ActItem("$candidate", "$candidate", "tap", null) }, 1),
                            },
                            new PlanItem[]
                            {
                                new PlanItem.IfItem(SettingsPlanFacts.AtRootCondition,
                                    new PlanItem[] { new PlanItem.ControlItem(PlanControlKind.Replan, "evaluate scoped results") },
                                    new PlanItem[] { new PlanItem.ActItem("ui.element", "Navigate up", "tap", null) }),
                            }),
                    }, 10),
                }, "discover current-page navigation and return; record controls through owner observations", "conditional-ui", MaxLocalOperations: 80));
            }, ViewportWidth: Width, ViewportHeight: Height, FeedNext: world.Next,
            CurrentCaptureId: () => world.CurrentCaptureId, EffectDriver: new SimulatedEffectDriver(world), UseCoverageDirector: false));
        Assert.Equal(RunDriveStatus.Completed, result.Status);
        Assert.Equal("CoverageComplete", result.Report.Status);
        Assert.Equal(new[] { "Network & internet", "Connection details", "Navigate up", "Navigate up", "Connected devices", "Navigate up" },
            result.Steps.Where(step => step.Verified).Select(step => step.TargetDescriptor));
        Assert.DoesNotContain(result.Steps, step => step.TargetDescriptor == "Record only setting");
        Assert.Equal(2, consults); // one strategy, then completion assessment
        Assert.Equal(RootRoute, world.Route);
        using var recorded = JsonDocument.Parse(File.ReadAllText(Path.Combine(result.RunDir, "coverage-observed-elements.json")));
        Assert.Contains(recorded.RootElement.EnumerateArray(), item => item.GetProperty("role").GetString() == "switch"
            && item.GetProperty("descriptor").GetString() == "Record only setting");
        using var planTrace = JsonDocument.Parse(File.ReadAllText(Path.Combine(result.RunDir, "plan-execution.json")));
        Assert.Contains(planTrace.RootElement.GetProperty("conditionEvaluations").EnumerateArray(), item =>
            item.GetProperty("condition").GetString() == SettingsPlanFacts.AtRootCondition
            && item.GetProperty("result").GetProperty("evidenceRefs").GetArrayLength() > 0);
    }

    [Fact]
    public void ConfiguredRenewal_ReachesRunner_AndKeepsFinalTotalBounded()
    {
        var path = WriteTempConfig(4, 4, 1);
        File.WriteAllText(path, File.ReadAllText(path).Replace("maxConsultRounds: 30",
            "maxConsultRounds: 3\n  maxTotalSteps: 12\n  maxTotalConsultRounds: 20\n  renewalThresholdSteps: 2\n  renewalThresholdRounds: 2"));
        var windows = new List<RenewalWindow?>();
        var result = RunScenario(context =>
        {
            windows.Add(context.RenewalWindow);
            var decision = ModelConsult(context);
            if (context.RenewalWindow is { Open: true } window && decision is AgentDecision.Act act)
                return act with { Proposal = act.Proposal with { Renewal = new BudgetRenewalRequest(
                    Math.Min(2, window.HardCapSteps - window.GrantedSteps),
                    Math.Min(4, window.HardCapRounds - window.GrantedRounds), "coverage progressing") } };
            return decision;
        }, SettingsCoverageConfig.Load(path));
        Assert.Contains(windows, window => window is { Open: true, HardCapSteps: 8, HardCapRounds: 17 });
        Assert.InRange(result.Steps.Count, 5, 12);
        Assert.InRange(windows.Count, 4, 20);
        using var facts = JsonDocument.Parse(File.ReadAllText(Path.Combine(result.RunDir, "facts.json")));
        var renewals = facts.RootElement.GetProperty("budgetRenewals").EnumerateArray().ToArray();
        Assert.Contains(renewals, grant => grant.GetProperty("granted").GetBoolean());
        Assert.True(renewals.Where(grant => grant.GetProperty("granted").GetBoolean())
            .Sum(grant => grant.GetProperty("additionalSteps").GetInt32()) <= 8);
        using var bridge = JsonDocument.Parse(File.ReadAllText(Path.Combine(result.RunDir, "consult-bridge.json")));
        Assert.Contains(bridge.RootElement.GetProperty("exchanges").EnumerateArray(), exchange =>
            exchange.GetProperty("decision").ValueKind == JsonValueKind.Object
            && exchange.GetProperty("decision").GetProperty("renewal").ValueKind == JsonValueKind.Object
            && exchange.GetProperty("effectiveDecision").GetProperty("renewal").GetProperty("additionalRounds").GetInt32() == 4);
        File.Delete(path);
    }

    [Fact]
    public void WriteEvidenceFile_PersistsPayloadUnderCaptureId()
    {
        // AGT-008：证据文件名 = captureId（与步骤 postCaptureId 直接关联）。
        var dir = Path.Combine(Path.GetTempPath(), $"settings-evidence-{Guid.NewGuid():N}");
        try
        {
            SettingsTraversalLiveFeed.WriteEvidenceFile(dir, "capture-abc.png", new byte[] { 1, 2, 3 });
            SettingsTraversalLiveFeed.WriteEvidenceFile(dir, "capture-abc.xml",
                System.Text.Encoding.UTF8.GetBytes("<hierarchy/>"));
            Assert.True(File.Exists(Path.Combine(dir, "capture-abc.png")));
            Assert.Equal(3, new FileInfo(Path.Combine(dir, "capture-abc.png")).Length);
            Assert.Contains("<hierarchy/>", File.ReadAllText(Path.Combine(dir, "capture-abc.xml")));
        }
        finally
        {
            if (Directory.Exists(dir)) Directory.Delete(dir, recursive: true);
        }
    }

    [Fact]
    public void TransitionalStartupScreen_DefersUntilSettled_ThenCompletes()
    {
        // AGT-006：首个观察为无标题过渡屏（路由回退身份）→ director Defer
        // 重观察而非指挥幻影 back；定形后任务照常完成。
        var world = new SimulatedSettingsWorld();
        world.StartTransitional(1);
        var assets = new LivePerception.LiveAssets(
            "emulator-sim", "wifi-settings", "/nonexistent", "/nonexistent/python", "/nonexistent/cache");
        var runRoot = Path.Combine(Path.GetTempPath(), $"settings-coverage-run-{Guid.NewGuid():N}");
        var result = SettingsCoverageRunner.Run(runRoot, new SettingsCoverageRunner.Options(
            DeviceId: "emulator-sim",
            Live: assets,
            Config: ConfigWith(),
            UnderlyingConsult: ModelConsult,
            FeedNext: world.Next,
            CurrentCaptureId: () => world.CurrentCaptureId,
            EffectDriver: new SimulatedEffectDriver(world)));

        Assert.True(result.Status == RunDriveStatus.Completed,
            $"{result.Status}({result.Reason}) divergence={result.Report.FirstDivergence}");
        Assert.Equal("CoverageComplete", result.Report.Status);
        Assert.Contains(result.Consults, c => c.DirectiveKind == "defer-unknown-page");
    }

    /// <summary>
    /// AGT-009 验收 7（Drive 级闭环）：遍历中途弹窗（permissioncontroller）→
    /// director obstacle 分支发出清障 directive → 模型以受约束 advisory Plan
    /// 回答（ActItem=词汇命中的 CANCEL tap + ObserveItem(popup 补证)）→
    /// Kernel 逐项执行：ActItem 经真实 grounding/Gate/dispatch（清障 tap 落地、
    /// 弹窗消失）→ ObserveItem/剩余计划由失效规则处置 → popup 声明转 absent
    /// → 普通遍历恢复并完成覆盖。
    /// </summary>
    [Fact]
    public void PopupEpisode_ObstaclePlanClearsPopup_AndResumesTraversalToCompletion()
    {
        var world = new SimulatedSettingsWorld();
        world.ArmPopupOnNextSecondLevelEntry();
        var assets = new LivePerception.LiveAssets(
            "emulator-sim", "wifi-settings", "/nonexistent", "/nonexistent/python", "/nonexistent/cache");
        var runRoot = Path.Combine(Path.GetTempPath(), $"settings-coverage-run-{Guid.NewGuid():N}");
        var result = SettingsCoverageRunner.Run(runRoot, new SettingsCoverageRunner.Options(
            DeviceId: "emulator-sim",
            Live: assets,
            Config: ConfigWith(),
            UnderlyingConsult: ObstaclePlanModelConsult,
            DshSessionIdAccessor: () => "session-sim-0001",
            FeedNext: world.Next,
            CurrentCaptureId: () => world.CurrentCaptureId,
            EffectDriver: new SimulatedEffectDriver(world)));

        // 闭环终点：弹窗已清（同分类器前后测：present → absent）且任务完成
        Assert.True(result.Status == RunDriveStatus.Completed,
            $"{result.Status}({result.Reason}) divergence={result.Report.FirstDivergence}");
        Assert.Equal("CoverageComplete", result.Report.Status);
        Assert.False(world.PopupActive);

        // obstacle 分支确实发生，且回答形态是受约束 advisory Plan
        var obstacle = result.Consults.Single(c => c.DirectiveKind == "obstacle");
        Assert.Equal("plan", obstacle.DecisionKind);
        Assert.Null(obstacle.DeviationReason);
        Assert.Contains("CANCEL", obstacle.Directive);

        // ActItem 经真实执行链落地：清障步骤有回执（click 型目标消失且路由
        // 未变——通用 target-unique check 如实失败，弹窗清障本身由
        // ui.overlay.popup present→absent 的 typed 声明证明；剩余计划按
        // 冻结决策 11 由验证失败废弃）
        var clearance = result.Steps.Single(s => s.TargetDescriptor == "CANCEL");
        Assert.Equal("DeliveryCompleted", clearance.ReceiptOutcome);
        Assert.Equal("obstacle-clearance-plan", obstacle.Justification);

        // 清障后普通遍历恢复：obstacle 咨询之后仍有正常 enter/scroll 指令
        var consultList = result.Consults.ToList();
        var obstacleIndex = consultList.IndexOf(obstacle);
        Assert.Contains(consultList.Skip(obstacleIndex + 1),
            c => c.DirectiveKind is "enter" or "re-enter" or "scroll" or "back");
        // 全部覆盖项最终完成（清障插曲不丢失任务）
        Assert.Empty(result.Report.UncoveredItems);
    }

    [Fact]
    public void PersistentUnknownPage_StopsHonestlyAfterDeferBudget()
    {
        // 过渡屏永不定形 → Defer 配额尽 → bounded-stop:unknown-page（fail closed）。
        var world = new SimulatedSettingsWorld();
        world.StartTransitional(999);
        var assets = new LivePerception.LiveAssets(
            "emulator-sim", "wifi-settings", "/nonexistent", "/nonexistent/python", "/nonexistent/cache");
        var runRoot = Path.Combine(Path.GetTempPath(), $"settings-coverage-run-{Guid.NewGuid():N}");
        var result = SettingsCoverageRunner.Run(runRoot, new SettingsCoverageRunner.Options(
            DeviceId: "emulator-sim",
            Live: assets,
            Config: ConfigWith(),
            UnderlyingConsult: ModelConsult,
            FeedNext: world.Next,
            CurrentCaptureId: () => world.CurrentCaptureId,
            EffectDriver: new SimulatedEffectDriver(world)));

        Assert.Equal("bounded-stop:unknown-page", result.Consults[^1].Justification);
        // 零 dispatch：未知页上从未发出任何 effect。
        Assert.Empty(result.Steps);
    }

    [Fact]
    public void FixedLanguageInspection_BindsAfterAdmission_AndPersistsPerCapture()
    {
        var world = new SimulatedSettingsWorld();
        var assets = new LivePerception.LiveAssets(
            "emulator-sim", "wifi-settings", "/nonexistent", "/nonexistent/python", "/nonexistent/cache");
        var runRoot = Path.Combine(Path.GetTempPath(), $"settings-coverage-language-{Guid.NewGuid():N}");
        var config = ConfigWith() with
        {
            LanguageInspection = new LanguageInspectionTaskRequest(
                Required: true,
                ExpectedLanguage: "en",
                FixedCapabilityId: LanguageInspectionProtocol.CapabilityId),
        };
        try
        {
            var result = SettingsCoverageRunner.Run(runRoot, new SettingsCoverageRunner.Options(
                DeviceId: "emulator-sim",
                Live: assets,
                Config: config,
                UnderlyingConsult: ModelConsult,
                FeedNext: world.Next,
                CurrentCaptureId: () => world.CurrentCaptureId,
                EffectDriver: new SimulatedEffectDriver(world),
                RuntimeIntegrationCapabilities: RuntimeIntegrationCapabilityComposition
                    .RegisterLanguageInspector()));

            var findingsPath = Path.Combine(result.RunDir, "language-findings.json");
            Assert.True(File.Exists(findingsPath));
            using var findings = JsonDocument.Parse(File.ReadAllText(findingsPath));
            Assert.True(findings.RootElement.GetProperty("findings").GetArrayLength() > 0);
            using var facts = JsonDocument.Parse(File.ReadAllText(Path.Combine(result.RunDir, "facts.json")));
            var language = facts.RootElement.GetProperty("languageInspection");
            Assert.True(language.GetProperty("requested").GetBoolean());
            Assert.Equal("language-findings.json", language.GetProperty("file").GetString());
            Assert.True(language.GetProperty("findings").GetInt32() > 0);
        }
        finally
        {
            if (Directory.Exists(runRoot))
                Directory.Delete(runRoot, recursive: true);
        }
    }

    [Fact]
    public void AgentLanguageInspectionSelection_BindsBeforePayloadExecution()
    {
        var world = new SimulatedSettingsWorld();
        var assets = new LivePerception.LiveAssets(
            "emulator-sim", "wifi-settings", "/nonexistent", "/nonexistent/python", "/nonexistent/cache");
        var runRoot = Path.Combine(Path.GetTempPath(), $"settings-coverage-language-agent-{Guid.NewGuid():N}");
        var config = ConfigWith() with
        {
            LanguageInspection = new LanguageInspectionTaskRequest(
                Required: true,
                ExpectedLanguage: "en"),
        };
        LanguageInspectionSelection? selected = null;
        AgentDecision? Consult(AgentDecisionContext context)
        {
            selected = new LanguageInspectionSelection(LanguageInspectionProtocol.CapabilityId, "en");
            return ModelConsult(context);
        }
        try
        {
            var result = SettingsCoverageRunner.Run(runRoot, new SettingsCoverageRunner.Options(
                DeviceId: "emulator-sim",
                Live: assets,
                Config: config,
                UnderlyingConsult: Consult,
                FeedNext: world.Next,
                CurrentCaptureId: () => world.CurrentCaptureId,
                EffectDriver: new SimulatedEffectDriver(world),
                LanguageInspectionSelectionProvider: () => selected,
                RuntimeIntegrationCapabilities: RuntimeIntegrationCapabilityComposition
                    .RegisterLanguageInspector()));

            Assert.True(File.Exists(Path.Combine(result.RunDir, "language-findings.json")));
            using var facts = JsonDocument.Parse(File.ReadAllText(Path.Combine(result.RunDir, "facts.json")));
            Assert.True(facts.RootElement.GetProperty("languageInspection").GetProperty("requested").GetBoolean());
        }
        finally
        {
            if (Directory.Exists(runRoot))
                Directory.Delete(runRoot, recursive: true);
        }
    }

    [Fact]
    public void GoalDirectedCompletion_RequiresDeclaredCoverageEvidenceBeyondRootPresence()
    {
        var config = ConfigWith();
        config = config with { Bounds = config.Bounds with { GoalDirectedContinuationEnabled = true } };
        var result = RunScenario(context => new AgentDecision.NoAction(
            new AgentNoActionProposal(context.DecisionId, "known todo is empty; claim completion")), config);
        Assert.Equal(RunDriveStatus.TerminalNotProven, result.Status);
        Assert.StartsWith("task-evidence-unproven:", result.Reason);
        Assert.NotEmpty(result.Report.UncoveredItems);
        Assert.Empty(result.Steps);
    }

    [Fact]
    public void FullCoverageMission_CompletesWithTraceableSteps()
    {
        var result = RunScenario(ModelConsult);

        Assert.True(result.Status == RunDriveStatus.Completed,
            $"{result.Status}({result.Reason}) divergence={result.Report.FirstDivergence}");
        Assert.Equal("Completion", result.Outcome);
        Assert.True(result.Report.Status == "CoverageComplete",
            $"{result.Status}/{result.Reason}: {JsonSerializer.Serialize(result.Report)}; run={result.RunDir}");
        Assert.Equal(1.0, result.Report.CoverageRate, 5);
        Assert.Equal(1.0, result.Report.StepSuccessRate, 5);
        Assert.Empty(result.Report.UncoveredItems);
        Assert.Null(result.Report.FirstDivergence);
        Assert.All(result.Report.Items, item => Assert.True(item.Covered, item.Requirement));

        // 步骤序列：8×(enter+back) + scroll + (scroll-entry+back) + (re-enter+back) = 21
        //（含 AGT-010 撞名页 Security & privacy——标题与根页同为 "Settings"）。
        Assert.Equal(21, result.Steps.Count);
        Assert.Equal(21, result.Steps.Count(s => s.Verified));
        Assert.All(result.Steps, s =>
        {
            Assert.NotNull(s.ReceiptId);
            Assert.Equal("DeliveryCompleted", s.ReceiptOutcome);
            Assert.True(s.PreActionTargetUnique, $"step {s.Index} target not unique");
            Assert.NotNull(s.RouteBefore);
            Assert.NotNull(s.RouteAfter);
            Assert.NotNull(s.PostCaptureId);
            Assert.Equal("session-sim-0001", s.DshSessionId);
            Assert.Contains(new KeyValuePair<string, bool>("post-action-target-unique", true), s.Checks);
        });

        // 滚动步骤：路由未变 + 内容变化 checks。
        var scroll = result.Steps.Single(s => s.EffectClass == "swipe-up");
        Assert.Equal(RootRoute, scroll.RouteBefore);
        Assert.Equal(RootRoute, scroll.RouteAfter);
        Assert.Contains(new KeyValuePair<string, bool>("post-action-route-unchanged", true), scroll.Checks);
        Assert.Contains(new KeyValuePair<string, bool>("post-action-content-transition", true), scroll.Checks);

        // 返回步骤：路由回到根页；重复进入：同 descriptor 两次、不同回执。
        var backs = result.Steps.Where(s => s.TargetDescriptor == "Navigate up").ToList();
        Assert.Equal(10, backs.Count);
        Assert.All(backs, b => Assert.Equal(RootRoute, b.RouteAfter));
        var batteryEntries = result.Steps.Where(s => s.TargetDescriptor == "Battery").ToList();
        Assert.Equal(2, batteryEntries.Count);
        Assert.NotEqual(batteryEntries[0].ReceiptId, batteryEntries[1].ReceiptId);

        // AGT-010 §2 验收 3：撞名页进入可验证——标题同为 "Settings" 的二级页
        // RouteAfter ≠ RootRoute（src/up/sc 多信号区分），验证通过。
        var colliding = result.Steps.Single(s => s.TargetDescriptor == CollidingPage);
        Assert.Equal("android.settings|rk1:Settings|src=title|up=1", colliding.RouteAfter);
        Assert.NotEqual(RootRoute, colliding.RouteAfter);
        Assert.True(colliding.Verified);

        // 工件落盘。
        Assert.True(File.Exists(Path.Combine(result.RunDir, "coverage-steps.json")));
        Assert.True(File.Exists(Path.Combine(result.RunDir, "coverage-report.json")));
        Assert.True(File.Exists(Path.Combine(result.RunDir, "facts.json")));
        Assert.True(File.Exists(Path.Combine(result.RunDir, "trace.json")));

        using var facts = JsonDocument.Parse(File.ReadAllText(Path.Combine(result.RunDir, "facts.json")));
        Assert.Equal("uniclaw.settings-coverage-facts.v2", facts.RootElement.GetProperty("schemaVersion").GetString());
        Assert.Equal(result.RunDir, facts.RootElement.GetProperty("runDir").GetString());
        Assert.True(facts.RootElement.GetProperty("diagnostics").GetProperty("nextFiles").GetArrayLength() >= 5);
        Assert.Contains("DecisionId", facts.RootElement.GetProperty("diagnostics").GetProperty("guidance").GetString());
        Assert.All(facts.RootElement.GetProperty("consults").EnumerateArray(), consult =>
            Assert.True(consult.TryGetProperty("justification", out _)));
    }

    [Fact]
    public void MaxStepsBound_StopsHonestlyWithUncoveredItems()
    {
        // maxSteps=6：进入 3 个入口后停止（bounded stop，不伪装完成）。
        var result = RunScenario(ModelConsult, ConfigWith(maxSteps: 6));

        Assert.Equal("BoundedStop", result.Report.Status);
        Assert.True(result.Report.CoverageRate < 1.0);
        Assert.NotEmpty(result.Report.UncoveredItems);
        Assert.Equal(6, result.Steps.Count);
    }

    /// <summary>
    /// AGT-010 §3 验收 4：滚动到底（内容不变）确定性背书——列表已在底部时
    /// swipe 不改变视口内容 → 滚动验证失败（post-action-content-transition
    /// 如实 false）→ 有界恢复耗尽后停止（bounded-stop:step-recovery-exhausted，
    /// 不盲重试、不伪装完成）。真机 d1/d3/d4 实录分支的确定性复刻。
    /// </summary>
    [Fact]
    public void ScrollAtBottom_ContentUnchanged_FailsVerification_BoundedStop()
    {
        var world = new SimulatedSettingsWorld();
        world.MakeAlreadyAtBottom();
        var assets = new LivePerception.LiveAssets(
            "emulator-sim", "wifi-settings", "/nonexistent", "/nonexistent/python", "/nonexistent/cache");
        var runRoot = Path.Combine(Path.GetTempPath(), $"settings-coverage-run-{Guid.NewGuid():N}");
        var result = SettingsCoverageRunner.Run(runRoot, new SettingsCoverageRunner.Options(
            DeviceId: "emulator-sim",
            Live: assets,
            Config: ConfigWith(),
            UnderlyingConsult: ModelConsult,
            DshSessionIdAccessor: () => "session-sim-0001",
            FeedNext: world.Next,
            CurrentCaptureId: () => world.CurrentCaptureId,
            EffectDriver: new SimulatedEffectDriver(world)));

        // 撞名已修（RouteKey）不再挡路；挡路的是诚实的滚动验证：内容不变 = 未生效
        Assert.Equal("BoundedStop", result.Report.Status);
        Assert.Equal("bounded-stop:step-recovery-exhausted", result.Consults[^1].Justification);
        var swipes = result.Steps.Where(s => s.EffectClass == "swipe-up").ToList();
        Assert.True(swipes.Count >= 1, "至少一次滚动尝试");
        Assert.All(swipes, s =>
        {
            Assert.Equal("DeliveryCompleted", s.ReceiptOutcome); // 已投递
            Assert.False(s.Verified, "内容不变的 swipe 不得验证通过");
            Assert.Contains(new KeyValuePair<string, bool>("post-action-content-transition", false),
                s.Checks);
        });
        // 滚动发现的入口保持未覆盖（诚实报告，不折叠）
        Assert.NotEmpty(result.Report.UncoveredItems);
    }

    [Fact]
    public void DeviatingModel_RecoversViaBoundedCorrectiveReconsult()
    {
        var result = RunScenario(DeviatingModelConsult);

        // 首轮偏离被纠正再咨询救回；任务仍完成。
        Assert.True(result.Status == RunDriveStatus.Completed,
            $"{result.Status}({result.Reason}) divergence={result.Report.FirstDivergence}");
        Assert.Equal("CoverageComplete", result.Report.Status);
        var first = result.Consults.First();
        Assert.Equal(2, first.Attempts);
        Assert.NotNull(first.DeviationReason);
        Assert.Contains("directive-target-mismatch", first.DeviationReason);
    }

    [Fact]
    public void PersistentlyDeviatingModel_FailsClosed()
    {
        // 零纠正预算 + 恒定偏离 → fail closed，且偏离留痕。
        AgentDecision? PersistentDeviation(AgentDecisionContext context) =>
            Act(context, "ui.element", "Storage", "tap");

        var result = RunScenario(PersistentDeviation, ConfigWith(maxDirectiveRetries: 0));

        Assert.True(result.Status == RunDriveStatus.AgentDecisionFailed,
            $"{result.Status}({result.Reason})");
        Assert.Contains(result.Consults, c => c.DeviationReason is not null);
        // 零 dispatch：偏离步骤不产生回执。
        Assert.Empty(result.Steps);
    }

    [Fact]
    public void MultiStepActProposal_IsRejectedAsDirectiveDeviation()
    {
        // AGT-011 §6：directive 要求单步；两步提案 = 偏离，有界纠正后仍
        // 偏离 → fail closed，零 dispatch。
        AgentDecision? TwoStepModel(AgentDecisionContext context) =>
            new AgentDecision.Act(new AgentActionProposal(
                context.DecisionId,
                new[]
                {
                    new AgentActionStep("ui.element", "Network & internet", "tap", null),
                    new AgentActionStep("ui.element", "Navigate up", "tap", null),
                },
                Justification: "two-step"));

        var result = RunScenario(TwoStepModel, ConfigWith(maxDirectiveRetries: 0));

        Assert.Equal(RunDriveStatus.AgentDecisionFailed, result.Status);
        Assert.Contains(result.Consults,
            c => c.DeviationReason == "directive-requires-single-step:2");
        Assert.Empty(result.Steps);
    }

    [Fact]
    public void IllegalDesiredStateOnDirectiveStep_IsRejectedByDirector()
    {
        AgentDecision? IllegalState(AgentDecisionContext context) =>
            new AgentDecision.Act(new AgentActionProposal(
                context.DecisionId,
                new[] { new AgentActionStep("ui.element", "Network & internet", "tap", "mostly-on") },
                Justification: "illegal-state"));

        var result = RunScenario(IllegalState, ConfigWith(maxDirectiveRetries: 0));

        Assert.Equal(RunDriveStatus.AgentDecisionFailed, result.Status);
        Assert.Contains(result.Consults,
            c => c.DeviationReason == "directive-step-must-not-carry-desiredState");
        Assert.Empty(result.Steps);
    }
}
